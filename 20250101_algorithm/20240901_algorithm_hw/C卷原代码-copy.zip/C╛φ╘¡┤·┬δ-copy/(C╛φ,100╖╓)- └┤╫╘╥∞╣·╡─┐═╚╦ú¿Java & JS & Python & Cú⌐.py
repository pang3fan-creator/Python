# 输入获取
k, n, m = map(int, input().split())


# 算法入口
def getResult():
    global k

    # 如果幸运数>=进制基数，比如m=2进制，要找n>=2的幸运数，那么肯定是没有的
    if n >= m:
        return 0

    count = 0

    # 除留取余
    while k > 0:
        remain = k % m  # 余数就是m进制的每一位上“位值”

        # 按照m进制的 “位值” 来对比幸运数 n
        if remain == n:
            count += 1

        k //= m

    return count


# 算法调用
print(getResult())