# 输入获取
import re

s = input()


# 计算合法表达式的结果
def calcExpStr(exp):
    # 这里在表达式结尾追加"+0"是为了避免后面收尾操作，不理解的话，可以去掉此步，测试下"1-2"
    exp += '+0'

    # 记录表达式中各块的操作数
    stack = []
    # 各块操作数的"值"部分的缓存容器
    numStr = []
    # 各块操作数的"系数"部分，默认为1
    num_coef = 1

    for c in exp:
        if '9' >= c >= '0':
            numStr.append(c)
            continue

        # 如果扫描到的字符c是运算符，那么该运算符打断了前面操作数的扫描，前面操作数 = 系数 * 值
        num = num_coef * int("".join(numStr))
        stack.append(num)

        # 清空缓存容器，用于下一个操作数的”值“记录
        numStr.clear()

        if c == '+':
            # 如果运算符是加法，则后一个操作数的系数为1
            num_coef = 1
        elif c == '-':
            # 如果运算符是减法，则后一个操作数的系数为-1
            num_coef = -1
        elif c == '*':
            # 如果运算符是乘法，则后一个操作数的系数为栈顶值，比如2*3，其中2可以当作3的系数
            num_coef = stack.pop()

    # 表达式分块后，每一块独立计算，所有块的和就是表达式的结果
    return sum(stack)


# 获取最长合法表达式
def getMaxLenExp():
    lst = re.compile(r"((?:\d+[+*-])*\d+)").findall(s)

    maxLenExp = ""

    for exp in lst:
        if len(exp) > len(maxLenExp):
            maxLenExp = exp

    return maxLenExp


# 算法入口
def getResult():
    maxLenExp = getMaxLenExp()

    if len(maxLenExp) == 0:
        return 0
    else:
        return calcExpStr(maxLenExp)


# 算法调用
print(getResult())
