# 输入获取
m, n, x = map(int, input().split())  # 产品数, 总投资, 总风险

# 产品回报率序列
back = list(map(int, input().split()))
# 产品风险值序列
risk = list(map(int, input().split()))
# 产品投资额序列
invest = list(map(int, input().split()))

# 记录所选产品的最大投资回报
max_invest_back = 0
# 记录所选产品的序号
select = {}

# 选两个产品时
for i in range(m):
    # 如果单个产品的投资风险未超过总风险，则投资单个产品
    if risk[i] <= x:
        # 产品I的投资额不能超过该产品的最大投资额，以及总投资
        investI = min(invest[i], n)
        # 产品投资回报
        invest_back = investI * back[i]

        # 如果投资回报高于其他产品组合，那么选择该产品
        if invest_back > max_invest_back:
            max_invest_back = invest_back
            select.clear()
            select[i] = investI
    else:
        continue

    for j in range(i + 1, m):
        # 如果两个产品的风险和不超过了总风险，那么两个产品都选
        if risk[i] + risk[j] <= x:
            investI = 0  # 产品I的投资额
            investJ = 0  # 产品J的投资额

            # 其中优先投资回报率大的
            if back[i] > back[j]:
                # 产品I回报率高，则能投多少投多少，最多不能超过min(总投资, 产品I的最多投资额)
                investI = min(n, invest[i])
                # 留给产品J的剩余钱未 n - investI, 而产品J最多投资invest[j]，因此取二者较小值
                investJ = min(n - investI, invest[j])
            else:
                investJ = min(n, invest[j])
                investI = min(n - investJ, invest[i])

            # 总投资回报
            invest_back = investI * back[i] + investJ * back[j]

            # 如果当前产品组合的总回报更大，则选当前组合产品
            if invest_back > max_invest_back:
                max_invest_back = invest_back
                select.clear()
                # select的key记录产品的ID，val记录产品的投资额
                if investI > 0:
                    select[i] = investI
                if investJ > 0:
                    select[j] = investJ

res = []
for i in range(m):
    if i in select:
        res.append(select[i])
    else:
        res.append(0)

print(" ".join(map(str, res)))
