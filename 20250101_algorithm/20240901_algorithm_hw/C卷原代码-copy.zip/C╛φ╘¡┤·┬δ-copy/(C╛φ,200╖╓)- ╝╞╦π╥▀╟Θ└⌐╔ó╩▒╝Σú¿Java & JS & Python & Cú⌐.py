import math

# 输入获取
arr = list(map(int, input().split(",")))


# 算法入口
def getResult(arr):
    # 题目说会输入n*n个值
    n = int(math.sqrt(len(arr)))

    #  将一维arr输入转为二维矩阵matrix
    matrix = [[0 for _ in range(n)] for _ in range(n)]

    # 将矩阵中所有感染区域位置记录到queue中,这里选择queue先进先出的原因是保证当天的感染区域并发扩散
    queue = []

    for i in range(n):
        for j in range(n):
            matrix[i][j] = arr[i * n + j]
            if matrix[i][j] == 1:
                queue.append([i, j])

    # 全是感染区，或全是健康区
    if len(queue) == 0 or len(queue) == len(arr):
        return -1

    # 健康区个数
    healthy = len(arr) - len(queue)

    # 上下左右偏移量
    offsets = ((-1, 0), (1, 0), (0, -1), (0, 1))

    # day用于统计感染全部花费的时间
    day = 0
    # 如果健康区个数为0，说明感染完了
    while len(queue) > 0 and healthy > 0:
        newQueue = []

        # 遍历完当前queue的所有感染区，即过去一天
        for x, y in queue:
            for offsetX, offsetY in offsets:
                newX = x + offsetX
                newY = y + offsetY

                if n > newX >= 0 and n > newY >= 0 and matrix[newX][newY] == 0:
                    healthy -= 1
                    matrix[newX][newY] = 1
                    # 新增感染区加到newQue中，不影响queue的当前遍历
                    newQueue.append([newX, newY])

        day += 1
        queue = newQueue

    return day


# 算法调用
print(getResult(arr))
