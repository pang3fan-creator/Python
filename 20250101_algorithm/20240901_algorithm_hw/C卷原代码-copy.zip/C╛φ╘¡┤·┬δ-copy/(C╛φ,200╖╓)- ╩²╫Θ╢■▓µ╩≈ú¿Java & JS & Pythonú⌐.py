import sys

# 输入获取
arr = list(map(int, input().split()))


# 算法入口
def getResult(arr):
    # 最小叶子节点的值
    minV = sys.maxsize
    # 最小节点在数组中的索引位置
    minIdx = -1
    n = len(arr) - 1

    for i in range(n, 0, -1):
        if arr[i] != -1:
            if i * 2 + 1 <= n and arr[i * 2 + 1] != -1:
                continue
            if i * 2 + 2 <= n and arr[i * 2 + 2] != -1:
                continue

            if minV > arr[i]:
                minV = arr[i]
                minIdx = i

    # path用于缓存最小叶子节点到根的路径
    path = []
    path.insert(0, str(minV))

    # 从最小值节点开始向上找父节点，直到树顶
    while minIdx != 0:
        f = (minIdx - 1) // 2
        path.insert(0, str(arr[f]))
        minIdx = f

    return " ".join(path)


# 算法调用
print(getResult(arr))
