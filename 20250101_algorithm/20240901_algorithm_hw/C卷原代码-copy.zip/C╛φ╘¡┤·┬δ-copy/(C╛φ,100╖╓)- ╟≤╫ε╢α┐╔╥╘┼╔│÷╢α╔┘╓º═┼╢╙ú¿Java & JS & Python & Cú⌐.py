# 输入获取
n = int(input())
capacities = list(map(int, input().split()))
minCap = int(input())


# 算法入口
def getResult():
    # 升序
    capacities.sort()

    l = 0
    r = n - 1

    # 记录题解
    ans = 0

    # 单人组队
    while r >= l and capacities[r] >= minCap:
        ans += 1
        r -= 1

    # 双人组队
    while l < r:
        total = capacities[l] + capacities[r]

        # 如果两个人的能力值之和>=minCap，则组队
        if total >= minCap:
            ans += 1
            l += 1
            r -= 1
        else:
            # 否则将能力低的人剔除，换下一个能力更高的人
            l += 1

    return ans


# 调用算法
print(getResult())