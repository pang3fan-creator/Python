# 输入获取
n, m = map(int, input().split())  # // 长n -> 行数, 宽m -> 列数
matrix = [list(map(int, input().split())) for _ in range(n)]  # 地图矩阵

# 向下、向右的偏移量
offsets = ((1, 0), (0, 1))

# 记录题解
ans = 0


# 深搜
def dfs(x, y):
    global ans

    if x == n - 1 and y == m - 1:
        # 如果当前分支可以走到终点，则对应分支路径可行
        ans += 1
        return

    # 从当前位置(x, y)向下或者向右走
    for offsetX, offsetY in offsets:
        # 新位置(newX, newY)
        newX = x + offsetX
        newY = y + offsetY

        # 如果新位置没有越界且新位置可以参观，则进入
        if n > newX >= 0 and m > newY >= 0 and matrix[newX][newY] == 0:
            dfs(newX, newY)


# 算法调用
if matrix[0][0] == 0:
    dfs(0, 0)  # 从(0,0)位置开始深搜，深搜对应的每条分支都对应一条路径
print(ans)
