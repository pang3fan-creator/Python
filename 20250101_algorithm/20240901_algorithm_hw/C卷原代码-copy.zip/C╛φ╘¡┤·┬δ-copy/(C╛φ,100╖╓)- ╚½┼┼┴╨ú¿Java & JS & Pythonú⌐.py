# 输入获取
s = input()


def getFact(n):
    fact = 1
    for i in range(1, n + 1):
        fact *= i
    return fact


# 算法入口
def getResult(s):
    total = getFact(len(s))

    count = {}
    for c in s:
        if count.get(c) is None:
            count[c] = 1
        else:
            count[c] += 1

    for c in count.keys():
        n = count[c]
        if n > 1:
            total /= getFact(n)

    return int(total)


# 算法调用
print(getResult(s))
