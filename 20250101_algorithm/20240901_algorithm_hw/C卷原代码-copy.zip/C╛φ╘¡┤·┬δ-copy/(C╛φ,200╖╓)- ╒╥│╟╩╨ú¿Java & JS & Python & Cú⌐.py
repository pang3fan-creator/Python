import sys

# 输入获取
n = int(input())
relations = [list(map(int, input().split())) for i in range(n - 1)]


# 并查集
class UnionFindSet:
    def __init__(self, n):
        self.fa = [i for i in range(n)]

    def find(self, x):
        if x != self.fa[x]:
            self.fa[x] = self.find(self.fa[x])
            return self.fa[x]
        return x

    def union(self, x, y):
        x_fa = self.find(x)
        y_fa = self.find(y)
        if x_fa != y_fa:
            self.fa[y_fa] = x_fa


# 算法入口
def getResult():
    # minDp用于保存最小城市聚集度
    minDp = sys.maxsize
    # city用于保存最小城市聚集度对应的被切割的城市序号
    city = []

    # 遍历每个城市 1~n
    for i in range(1, n + 1):
        # 利用并查集对城市进行关联
        ufs = UnionFindSet(n + 1)

        for x, y in relations:
            # 切断城市的所有道路，即忽略和城市i有联系的合并操作
            if x == i or y == i:
                continue
            # 否则连接x和y
            ufs.union(x, y)

        # 统计各个连通分量自身的城市个数
        cnts = [0] * (n + 1)
        for j in range(1, n + 1):
            fa = ufs.find(j)
            cnts[fa] += 1

        #  取最多城市个数作为当前的切断城市的聚集度
        dp = max(cnts)

        if dp < minDp:
            minDp = dp
            city = [i]
        elif dp == minDp:
            city.append(i)

    # 如果有多个，按照编号升序输出。
    city.sort()
    return " ".join(map(str, city))


# 算法调用
print(getResult())
