import re

# 输入获取
s = input()
pre = input()


# 算法入口
def getResult(s, pre):
    tmp = re.split("[^a-zA-Z]", s)
    cache = list(set(tmp))
    cache.sort()
    cache = list(filter(lambda x: x.startswith(pre), cache))
    if len(cache) > 0:
        return " ".join(cache)
    else:
        return pre


# 算法调用
print(getResult(s, pre))
