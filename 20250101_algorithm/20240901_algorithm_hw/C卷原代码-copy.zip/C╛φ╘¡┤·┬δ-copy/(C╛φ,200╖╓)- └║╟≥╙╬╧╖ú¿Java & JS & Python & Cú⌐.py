# 输入获取
ipts = list(map(int, input().split(",")))
opts = list(map(int, input().split(",")))


# 算法入口
def getResult():
    # 利用队列结构模拟圆桶
    queue = []
    # outputs[index]是要被取出的篮球的编号
    index = 0

    # 记录题解
    res = []

    for ipt in ipts:
        # 按照放入顺序，从圆桶右边放入
        queue.append(ipt)

        # 然后开始尝试取出
        while len(queue) > 0:
            # 圆桶左边的篮球的编号
            left = queue[0]
            # 圆桶右边的篮球的编号
            right = queue[-1]

            if left == opts[index]:
                # 优先比较圆桶左边的篮球是不是当前要取出的篮球，优先左边的原因是：当桶只有一个篮球的情况下，必须从左边取出
                res.append("L")
                queue.pop(0)
                index += 1
            elif right == opts[index]:
                # 比较圆桶右边的篮球是不是当前要取出的篮球
                res.append("R")
                queue.pop()
                index += 1
            else:
                # 如果圆桶左右两边都不是要取出的球，则本轮取出流程结束
                break

    # 最终如果圆桶空了，则说明所有球都取出了，否则按照给定要求无法取出所有球
    if len(queue) != 0:
        return "NO"
    else:
        return "".join(map(str, res))


# 算法调用
print(getResult())
