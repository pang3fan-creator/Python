# 输入获取
s = input()


def isSign(c):
    return c == '+' or c == '-'


def isDot(c):
    return c == '.'


# ”±”仅能出现在开头且其后必须要有数字
def isValidSign(signIdx):
    nxtIdx = signIdx + 1
    return nxtIdx < len(s) and s[nxtIdx].isdigit()


# ”.”的两边必须是数字
def isValidDot(dotIdx):
    preIdx = dotIdx - 1
    nxtIdx = dotIdx + 1
    return preIdx >= 0 and s[preIdx].isdigit() and nxtIdx < len(s) and s[nxtIdx].isdigit()


# 记录数字串时，只保留最长的数字串
def getAns(l, r, ans):
    # 如果存在长度相同的连续数字串，返回最后一个。 因此下面判断是>=
    return s[l:r] if l < len(s) and r - l >= len(ans) else ans


# 从s字符串的start位置开始找数字串的开头字符，数字串的开头字符可以是数字，也可以是符号
def findStartIdx(i):
    while i < len(s):
        c = s[i]

        if c.isdigit() or (isSign(c) and isValidSign(i)):
            break

        i += 1

    return i


# 算法入口
def getResult():
    # 记录题解
    ans = ""

    # 记录数字串中“.”的位置，-1表示数字串中没有点
    dotIdx = -1

    # l 指向数字串的开头
    l = findStartIdx(0)

    # r 用于扫描数字串
    r = l + 1
    while r < len(s):
        # 当前扫描的到的字符
        c = s[r]

        if c.isdigit():
            # c是数字，则继续扫描下一个
            r += 1
        elif isSign(c):
            # c是加减号，则数字串扫描中断，我们需要先记录[l, r-1]范围的数字串
            ans = getAns(l, r, ans)

            if isValidSign(r):
                # 由于加减号可以作为数字串开头，如果r位置的加减号是一个合法数字串开头加减号，则可以当成下一个数字串的开头
                l = r
            else:
                # 否则，从r+1开始继续找下一个数字的开头
                l = findStartIdx(r + 1)

            # 新数字串的开头找到后，从l+1开始扫描
            r = l + 1
            # 同时注意重置dotIdx记录
            dotIdx = -1
        elif isDot(c):
            # 由于dot处理比较复杂，这里无论dot是否会中断数字串扫描，都先将[l, r-1]部分的数字串记录下来
            ans = getAns(l, r, ans)

            if isValidDot(r):
                # 如果是合法数字串dot, 则判断当前数字串是否已存在”.“
                if dotIdx != -1:
                    # 如果已存在".", 则当前数字串包含了两个"."，肯定不合法，此时需要舍弃第一个".", 即新数字串开头位置设置在第一个"."后面
                    l = dotIdx + 1

                # 更新dotIdx为第二个"."的位置
                dotIdx = r
                # r继续扫描下一个
                r += 1
            else:
                # 如果不是合法数字串dot，即该dot前后不都是数字，则新数字串不能包含进当前dot位置，新数字串开头需要从r+1开始找
                l = findStartIdx(r + 1)
                r = l + 1
                dotIdx = -1
        else:
            # c是其他字符, 则数字串被打断，此时需要先记录[l, r-1]范围的当前数字串， 然后重新寻找下一个数字串的开头
            ans = getAns(l, r, ans)
            l = findStartIdx(r + 1)
            r = l + 1
            dotIdx = -1

    return getAns(l, r, ans)


# 算法调用
print(getResult())
