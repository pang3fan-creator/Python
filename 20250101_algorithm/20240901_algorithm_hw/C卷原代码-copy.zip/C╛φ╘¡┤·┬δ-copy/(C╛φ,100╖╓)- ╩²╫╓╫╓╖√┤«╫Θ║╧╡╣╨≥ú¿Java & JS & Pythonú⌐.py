# 输入获取
import re

s = input()


# 算法入口
def getResult():
    # 非字母、数字、-的字符都当成单词之间的分隔符
    words = re.split(r"[^0-9a-zA-Z\-]", s)

    # 记录题解
    ans = []

    # 倒序遍历单词
    for i in range(len(words) - 1, -1, -1):
        word = words[i]

        if word == "":
            continue

        # 单词左、右边界不能是 -
        word = word.strip('-')

        # 单词中间的"--"视为分隔符
        subWords = re.split(r"-{2,}", word)

        # 按照"--"分割后，倒序记录入ans
        for j in range(len(subWords) - 1, -1, -1):
            if subWords[j] != "":
                ans.append(subWords[j])

    return " ".join(ans)


# 算法调用
print(getResult())