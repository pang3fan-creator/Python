# 输入获取
s = input()


# 算法入口
def getResult():
    stack = []

    for c in s:
        if c < 'A' or c > 'z' or 'Z' < c < 'a':
            return 0

        if len(stack) > 0 and stack[-1] == c:
            stack.pop()
        else:
            stack.append(c)

    return len(stack)


# 算法调用
print(getResult())
