# 输入获取
h, n = map(int, input().split())
heights = list(map(int, input().split()))


# 算法入口
def getResult():
    heights.sort(key=lambda x: (abs(x - h), x))
    return " ".join(map(str, heights))


# 调用算法
print(getResult())
