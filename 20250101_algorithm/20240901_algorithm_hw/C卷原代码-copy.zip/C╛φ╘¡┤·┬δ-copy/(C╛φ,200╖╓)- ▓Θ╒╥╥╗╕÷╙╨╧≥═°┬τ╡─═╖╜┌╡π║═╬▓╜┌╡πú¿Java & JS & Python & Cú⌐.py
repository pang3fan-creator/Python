# 输入获取
n = int(input())
tmp = list(map(int, input().split()))


# 算法入口
def getResult():
    # 记录每个点的入度
    inDegree = {}
    # 记录每个点的后继点集合
    nxt = {}

    # 记录图中点
    points = set()

    for i in range(0, 2 * n, 2):
        # 从 a 到 b 的路径
        a = tmp[i]
        b = tmp[i + 1]

        # 收集图中所有节点
        points.add(a)
        points.add(b)

        # b点入度+1
        inDegree.setdefault(b, 0)
        inDegree[b] += 1

        # a点的后继点集合纳入b
        nxt.setdefault(a, [])
        nxt[a].append(b)

    # 图中总共total个节点
    total = len(points)

    # head记录图的头节点
    head = 0
    # 队列记录入度为0的点
    queue = []

    for p in points:
        # 题目描述中说图中只有一个首节点，首节点是入度为0的节点，因此如果某节点p没有入度，则为头节点
        if p not in inDegree:
            head = p
            queue.append(p)
            break

    # tails记录所有尾节点
    tails = []

    # count记录已被剥去的点个数，如果图中存在环，则必然最终count < total
    count = 0

    while len(queue) > 0:
        # 剥离入度为0的点
        fa = queue.pop(0)
        count += 1

        # 如果fa没有后继点，即fa没有出度，则fa是尾节点
        if fa not in nxt:
            tails.append(fa)
            continue

        # 如果fa有后继点，则其所有后继点入度-1
        for ch in nxt[fa]:
            inDegree[ch] -= 1

            # 如果ch点入度变为0，则加入队列
            if inDegree[ch] == 0:
                queue.append(ch)

    if count != total:
        # 如果存在环，则必然count < total
        print(-1)
    else:
        # 如果不存在环，则打印头节点和尾节点
        # 注意本题描述存在冲突（用例2输出的尾节点是从小到大排序的，而题目输出描述是要求尾节点从大到小排序），这里以用例为准
        tails.sort()
        print(head, " ".join(map(str, tails)))


# 算法调用
getResult()
