# 输入获取
nums = list(map(int, input().split()))


# 算法入口
def getResult():
    # 如果只有一个积木，那么只能是一层高度
    if len(nums) == 1:
        return 1

    # 如果有两个积木
    if len(nums) == 2:
        # 如果两个积木长度相同，则最大高度为2
        # 如果两个积木长度不同，则最大高度为1
        return 1 if nums[0] != nums[1] else 2

    # 积木按长度降序
    nums.sort(reverse=True)

    # 一层的最小长度，即最长的积木的长度
    minLen = nums[0]
    # 一层的最大长度
    maxLen = nums[0] + nums[-1]

    # 尝试minLen和maxLen中每一个值作为一层长度
    for length in range(minLen, maxLen + 1):
        # 对应一层长度限制下的最大高度
        height = 0

        # 通过l,r指针去选择组成一层的一个或两个积木
        # l指针指向最大长度的积木
        l = 0
        # r指针指向最小长度的积木
        r = len(nums) - 1

        # 如果最大长度的积木，可以独立一层，则l++，height++
        while l < len(nums) and nums[l] == length:
            l += 1
            height += 1

        while l < r:
            # 如果 l,r积木无法组成一层
            # 假设nums[l] + nums[r] > length，则必然nums[l] + nums[r-1] > length，因为nums已降序，nums[r-1] >= nums[r]，即必然l积木无法和其他积木组成一层
            # 假设nums[l] + nums[r] < length，则必然nums[l+1] + nums[r] < length，因为nums已降序，nums[l+1] <= nums[l]，即必然r积木无法和其他积木组成一层
            if nums[l] + nums[r] != length:
                break
            else:
                l += 1
                r -= 1
                height += 1

        # 如果正常结束，则必然l > r，否则就是异常结束
        if l <= r:
            continue

        return height

    return -1


# 算法调用
print(getResult())
