# 输入获取
n = int(input())
arr = list(map(int, input().split()))


# 算法入口
def getResult():
    arr.sort(reverse=True)

    for i in range(n):
        for j in range(i + 1, n):
            for k in range(j + 1, n):
                if arr[i] == arr[j] + 2 * arr[k]:
                    return f"{arr[i]} {arr[j]} {arr[k]}"

                if arr[i] == arr[k] + 2 * arr[j]:
                    return f"{arr[i]} {arr[k]} {arr[j]}"

    return "0"


# 算法调用
print(getResult())