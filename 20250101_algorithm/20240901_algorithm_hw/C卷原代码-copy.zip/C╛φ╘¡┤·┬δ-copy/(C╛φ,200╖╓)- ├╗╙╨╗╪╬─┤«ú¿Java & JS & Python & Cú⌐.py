# 输入获取
n = int(input())
s = input()


# 算法入口
def getResult():
    # 将输入的字符串转化为ASCII数组
    chars = list(map(lambda x: ord(x), list(s)))
    # 每一位上的最大ASCII值
    limit = 97 + n - 1

    # 当前位是否处于回退检查状态
    back = False

    # 从最低位开始检查
    i = len(chars) - 1
    while i >= 0:
        # 如果当前位还有新增空间
        if chars[i] < limit:
            if not back:
                # 如果当前位不是回退检查状态,则当前位ASCII+1
                chars[i] += 1
            else:
                # 如果当前位是回退检查状态, 则重置back
                back = False

            # 避免出现 *abb* 这种情况
            if i - 1 >= 0 and chars[i] == chars[i - 1]:
                continue

            # 避免出现 *aba* 这种情况
            if i - 2 >= 0 and chars[i] == chars[i - 2]:
                continue

            # 如果都没有出现上面两个情况：
            # 当前检查位是最低位，则说明当前字符串不含回文串, 可以直接返回当前字符串
            if i == len(chars) - 1:
                return "".join(map(chr, chars))

            # 当前检查位不是最低位，则只完成了高位的回文检查，还要回退到低位检查
            i += 1
            # 由于回退到了低位，则标记当前i指向的位置为回退检查状态，即检查时不进行ASCII+1操作
            back = True
        else:
            # 当前位没有新增空间了, 因此i位（低位）变为'a',  i-1位（高位）+ 1
            chars[i] = 97
            i -= 1

    return "NO"


# 算法调用
print(getResult())
