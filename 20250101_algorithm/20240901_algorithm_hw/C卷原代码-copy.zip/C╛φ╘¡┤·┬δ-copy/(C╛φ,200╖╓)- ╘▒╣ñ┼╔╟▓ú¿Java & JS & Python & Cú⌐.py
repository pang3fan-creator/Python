# 输入获取
import sys

x, y, cntx, cnty = map(int, input().split())


def check(k):
    A = k // x  # 1~k范围内x倍数的数量
    B = k // y  # 1~k范围内y倍数的数量
    C = k // (x * y)  # 1~k范围内x*y倍数的数量

    return max(0, cntx - (B - C)) + max(0, cnty - (A - C)) <= k - A - B + C


def getResult():
    low = cntx + cnty
    # high = sys.maxsize  # 使用此上限，实际通过率55%
    high = 1000000000  # 使用此上限，实际通过率可以100%

    while low <= high:
        mid = (low + high) // 2

        if check(mid):
            high = mid - 1
        else:
            low = mid + 1

    return low


print(getResult())
