import sys

# 输入获取
m, n = map(int, input().split())  # 棋盘行数, 棋盘列数
grid = [input() for _ in range(m)]  # 棋盘矩阵
stepGrid = [[0] * n for _ in range(m)]  # 最小步数和矩阵，stepMap[i][j]记录各个马走到棋盘(i,j)位置的最小步数之和

# 记录所有马都可达的公共位置坐标
reach = set()
for i in range(m):
    for j in range(n):
        reach.add(i * n + j)

# 马走日的偏移量
offsets = ((1, 2), (1, -2), (2, 1), (2, -1), (-1, 2), (-1, -2), (-2, 1), (-2, -1))


# 广搜
def bfs(sx, sy, k):
    global reach

    # 广搜队列
    # (sx,sy)为马所在初始位置，马到达初始位置需要0步
    queue = [(sx, sy, 0)]

    # 记录该马可以访问(sx,sy)位置
    vis = set()
    vis.add(sx * n + sy)  # 二维坐标一维化

    # k记录该马剩余可走步数
    while len(queue) > 0 and k > 0:
        # newQueue记录该马花费相同步数的可达的位置（即BFS按层遍历的层）
        newQueue = []

        # 按层BFS
        for x, y, step in queue:
            for offsetX, offsetY in offsets:
                # 马走日到达的新位置
                newX = x + offsetX
                newY = y + offsetY

                pos = newX * n + newY

                # 如果新位置越界或者已访问过，则不能访问
                if newX < 0 or newX >= m or newY < 0 or newY >= n or (pos in vis):
                    continue

                # 将新位置加入新层
                newQueue.append((newX, newY, step + 1))

                # 该马到达(newX, newY)位置最小步数为step+1, 由于该马首次到达(newX, newY)位置，因此step+1就是最小步数
                stepGrid[newX][newY] += step + 1

                # 记录该马访问过该位置，后续如果该马再次访问该位置，则不是最小步数
                vis.add(pos)

        queue = newQueue
        k -= 1  # 剩余步数减1

    # BFS完后，将公共可达位置reach和当前马可达位置vis取交集，交集部分就是新的公共可达位置
    reach &= vis


# 算法入口
def getResult():
    # 遍历棋盘
    for i in range(m):
        for j in range(n):
            # 如果棋盘(i,j)位置是马
            if grid[i][j] != '.':
                # 马的等级
                k = int(grid[i][j])
                # 对该马进行BFS走日
                bfs(i, j, k)

    # 如果所有马走完，发现没有公共可达位置
    if len(reach) == 0:
        return -1

    # 记录所有马都可达位置的最小步数和
    minStep = sys.maxsize

    for pos in reach:
        x = pos // n
        y = pos % n
        # (x,y)是所有马都可达的位置，stepMap[x][y]记录所有马到达此位置的步数和
        minStep = min(minStep, stepGrid[x][y])

    return minStep


# 算法调用
print(getResult())
