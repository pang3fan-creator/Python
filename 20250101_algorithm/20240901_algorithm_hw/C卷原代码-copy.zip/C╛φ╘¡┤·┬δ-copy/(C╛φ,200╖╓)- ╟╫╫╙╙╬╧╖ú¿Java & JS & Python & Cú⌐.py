# 输入获取
n = int(input())

queue = []

candy = [[-1] * n for _ in range(n)]

matrix = []
for i in range(n):
    matrix.append(list(map(int, input().split())))

    for j in range(n):
        # 妈妈的位置
        if matrix[i][j] == -3:
            candy[i][j] = 0
            queue.append((i, j))

offsets = ((0, -1), (0, 1), (-1, 0), (1, 0))


# 算法入口
def bfs():
    global queue

    # 记录题解
    ans = -1

    # bfs 按层扩散
    while len(queue) > 0:
        # 记录当前扩散层的点
        newQueue = []

        # 当前层是否有宝宝所在的点
        flag = False

        # 源点坐标
        for x, y in queue:
            # 向四个方向扩散
            for offsetX, offsetY in offsets:
                # 当前扩散点坐标
                newX = x + offsetX
                newY = y + offsetY

                # 当前扩散点坐标越界，或者扩散点是墙，则无法扩散
                if newX < 0 or newX >= n or newY < 0 or newY >= n or matrix[newX][newY] == -1:
                    continue

                # 当前扩散点坐标对应的糖果数量为-1，说明对应扩散点坐标位置还没有加入到当前扩散层
                if candy[newX][newY] == -1:
                    newQueue.append((newX, newY))  # 加入当前扩散层

                # 当前扩散点可能会被多个源点扩散到，因此比较保留扩散过程中带来的较大糖果数
                # candy[newX][newY] 记录的是当前扩散点获得的糖果数
                # candy[x][y] + max(0, matrix[newX][newY]) 记录的是从源点(x,y)带来的糖果数 + (newX,newY)位置原本的糖果数
                candy[newX][newY] = max(candy[newX][newY], candy[x][y] + max(0, matrix[newX][newY]))

                # 如果当前扩散点是宝宝位置，则可以停止后续层级的bfs扩散，因为已经找到宝宝的最短路径长度（即扩散层数）
                if matrix[newX][newY] == -2:
                    ans = candy[newX][newY]
                    flag = True

        # 已经找到去宝宝位置的最短路径和最大糖果数，则终止bfs
        if flag:
            break

        # 否则继续
        queue = newQueue

    return ans


# 算法调用
print(bfs())
