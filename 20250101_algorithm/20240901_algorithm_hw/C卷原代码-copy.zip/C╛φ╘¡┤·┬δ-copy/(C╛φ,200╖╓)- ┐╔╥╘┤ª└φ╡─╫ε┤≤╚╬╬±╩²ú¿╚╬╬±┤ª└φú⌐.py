import heapq
import sys

# 输入获取
n = int(input())
ranges = [list(map(int, input().split())) for _ in range(n)]


# 算法入口
def getResult():
    # 将所有任务按照结束时间降序
    ranges.sort(key=lambda x: -x[1])

    # 优先队列中记录的是任务的开始时间，并且开始时间越大，优先级越高
    # 由于heapq默认是数值越小，优先级越大，因此这里存入负数的开始时间到pq
    pq = []

    # 优先队列中记录的是结束时间相同的任务的开始时间，pq_end就是优先队列中任务的相同结束时间
    pq_end = sys.maxsize

    # 最大任务数
    count = 0

    # 当前任务的开始和结束时间
    for start, end in ranges:
        # 如果当前任务的结束时间 小于 优先队列中记录的任务的结束时间，则两个结束时间之间的间隔时间段，可以处理一些紧急任务
        while len(pq) > 0 and end < pq_end:
            # 这里的紧急任务即指时间短的任务，即开始时间比较大的任务
            if -heapq.heappop(pq) <= pq_end:
                # 如果紧急任务的开始时间未超过其结束时间，则可以执行
                count += 1
                pq_end -= 1  # 一个时刻只执行一个任务

        # 间隔时间消耗完后，优先队列中的任务的结束时间全部更新为当前任务的结束时间
        heapq.heappush(pq, -start)
        pq_end = end

    # 收尾处理
    while len(pq) > 0:
        if -heapq.heappop(pq) <= pq_end:
            count += 1
            pq_end -= 1

    return count


# 算法调用
print(getResult())
