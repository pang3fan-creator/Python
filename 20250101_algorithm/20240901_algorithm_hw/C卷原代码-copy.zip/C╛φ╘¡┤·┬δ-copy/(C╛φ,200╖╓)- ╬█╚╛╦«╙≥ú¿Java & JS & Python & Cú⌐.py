import math

# 输入获取
nums = list(map(int, input().split(",")))


# 算法入口
def getResult():
    # 矩阵 n x n
    n = int(math.sqrt(len(nums)))

    # 未污染区域数量
    total = len(nums)

    # 矩阵
    matrix = [[0 for _ in range(n)] for _ in range(n)]

    # BFS队列
    queue = []

    for i in range(n):
        for j in range(n):
            matrix[i][j] = nums[i * n + j]
            if matrix[i][j] == 1:
                queue.append([i, j])
                total -= 1

    if len(queue) == 0 or len(queue) == len(nums):
        return -1

    # 上下左右偏移量
    offsets = ((-1, 0), (1, 0), (0, -1), (0, 1))

    # 扩散天数
    day = 0

    while len(queue) > 0 and total > 0:
        newQueue = []

        for i, j in queue:
            for offsetX, offsetY in offsets:
                newI = i + offsetX
                newJ = j + offsetY

                if 0 <= newI < n and 0 <= newJ < n and matrix[newI][newJ] == 0:
                    matrix[newI][newJ] = 1
                    newQueue.append([newI, newJ])
                    total -= 1

        queue = newQueue
        day += 1

    return day


# 算法调用
print(getResult())
