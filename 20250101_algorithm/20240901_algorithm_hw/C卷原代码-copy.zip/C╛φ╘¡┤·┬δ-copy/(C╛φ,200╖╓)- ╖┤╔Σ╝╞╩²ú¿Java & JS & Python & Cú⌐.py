# 输入获取
w, h, x, y, sx, sy, t = map(int, input().split())
matrix = [input() for _ in range(h)]


# 算法入口
def getResult():
    global x, y, sx, sy, t
    ans = 0

    while t >= 0:
        # 注意本题横纵坐标是反的，因此y其实是行号，x是列号
        if matrix[y][x] == '1':
            ans += 1

        y += sy
        x += sx

        if x < 0:
            x = 1
            sx = -sx
        elif x >= w:  # 注意本题横纵坐标是反的，因此x是列号，w是矩阵列数
            x = w - 2
            sx = -sx

        if y < 0:
            y = 1
            sy = -sy
        elif y >= h:  # 注意本题横纵坐标是反的，因此y是行号，h是矩阵行数
            y = h - 2
            sy = -sy

        t -= 1

    return ans


# 算法调用
print(getResult())
