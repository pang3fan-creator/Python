# 输入获取
s = input()
l = input()


# 算法入口
def getResult():
    i = 0
    j = 0

    while i < len(s) and j < len(l):
        if s[i] == l[j]:
            i += 1
        j += 1

    if i == len(s):
        return j - 1
    else:
        return -1


# 算法调用
print(getResult())
