def getResult():
    dic = {}

    while True:
        try:
            player, gesture = input().split()

            # 如果有人不按套路出，则此局作废
            if gesture < 'A' or gesture > 'C':
                print("NULL")
                return

            # 统计各个手势的人名
            dic.setdefault(gesture, [])
            dic[gesture].append(player)

        except:
            break

    kinds = len(dic)

    if kinds == 1 or kinds == 3:
        # 只有一种手势，或者三种手势都有，则平局
        print("NULL")
    else:
        ans = None

        if 'A' not in dic:
            # 没有A手势，只有B、C手势，则B赢
            ans = dic['B']
        elif 'B' not in dic:
            # 没有B手势，只有A、C手势，则C赢
            ans = dic['C']
        else:
            # 没有C手势，只有A、B手势，则A赢
            ans = dic['A']

        ans.sort()

        for an in ans:
            print(an)


# 算法调用
getResult()