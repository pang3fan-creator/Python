# 输入获取
nums = list(map(int, input().split(",")))
level = int(input())


def dfs(index, path, res):
    if len(path) >= level:
        # 如果path层数到达level层，则记录该组合
        res.append(",".join(map(str, path)))

    for i in range(index, len(nums)):
        # 树层去重
        if i > 0 and nums[i] == nums[i - 1]:
            continue

        path.append(nums[i])
        dfs(i + 1, path, res)
        path.pop()


# 算法入口
def getResult():
    # 按照数值大小升序，这样后续形成的组合的内部就是按照数值大小升序的
    nums.sort()

    # 求不重复组合
    res = []
    dfs(0, [], res)

    if len(res) > 0:
        # 组合间按照字典序排序
        res.sort()
        return "\n".join(res)
    else:
        return "None"


# 调用算法
print(getResult())
