# 输入获取
tmp = input().split()


# 输入转换
def convert(s):
    num = int(s[:-1])
    unit = s[-1]

    if unit == 'Y':
        return num
    else:
        return num * 7


arr = list(map(convert, tmp))


# 算法入口
def getResult():
    ans = 0
    for i in range(1, len(arr)):
        ans += max(0, arr[i] - arr[i - 1])
    return ans


# 算法调用
print(getResult())
