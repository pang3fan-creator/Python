import sys

# 输入获取
wa, wb, wt, pa, pb = map(int, input().split())


# 算法入口
def getResult(bag, n, w, p):
    """
    完全背包
    :param bag: 背包承重
    :param n: 物品种数
    :param w: 物品的重量数组
    :param p: 物品的价值数组
    :return: 装满背包的最大价值
    """

    # dp[i]表示装满承重为 i 的背包的最大价值
    # 装满背包的背包问题，初始化时需要将除了dp[0]外的dp元素值设为负无穷
    dp = [-sys.maxsize for _ in range(bag + 1)]
    dp[0] = 0

    # 遍历物品
    for i in range(n):
        # 遍历背包承重，完全背包这里要正序遍历
        for j in range(w[i], bag + 1):
            dp[j] = max(dp[j], dp[j - w[i]] + p[i])

    # 返回装满承重为bag的背包的最大价值
    return dp[bag]


# 算法调用
# 背包承重, 这里减去必然需要装入的一件A货物和一件B货物
wt -= wa + wb

# 物品的重量
w = [wa, wb]
# 物品的价值
p = [pa, pb]

# maxP是装满承重为 wt 的背包的最大价值
maxP = getResult(wt, 2, w, p)

if maxP >= 0:
    # 如果maxP是非负数，则存在装满背包的方案，注意最后返回结果需要加上初始装上车的一件A和一件B的利润
    print(maxP + pa + pb)
else:
    # 如果maxP是负数，则说明不存在装满wt的方案，此时直接直接0
    print(0)
