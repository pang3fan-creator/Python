# 输入获取
s = input()


# 算法入口
def getResult():
    maxLen = -1

    l = 0
    r = 0
    letterIdx = []
    hasLetter = False

    while r < len(s):
        if s[r].isalpha():
            hasLetter = True
            letterIdx.append(r)

            if len(letterIdx) > 1:
                l = letterIdx.pop(0) + 1

            if r == l:
                r += 1
                continue

        maxLen = max(maxLen, r - l + 1)
        r += 1

    if not hasLetter:
        return -1
    return maxLen


# 算法调用
print(getResult())