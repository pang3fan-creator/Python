class TData:
    def __init__(self):
        self.price = 0
        self.vec = []


def main():
    nums = int(input())
    money = [TData() for _ in range(51)]

    money[0].price = 1
    money[1].price = 1
    money[1].vec.append(1)

    money[2].price = 2
    money[2].vec.append(2)

    money[3].price = 3
    money[3].vec.append(3)

    money[4].price = 4
    money[4].vec.append(4)

    money[5].price = 6
    money[5].vec.extend([2, 3])

    for i in range(6, nums + 1):
        max_value = i
        from_idx = 0
        to_idx = 0
        times = 0

        for j in range(1, i // 2 + 1):
            current_product = money[j].price * money[i - j].price
            current_times = len(money[j].vec) + len(money[i - j].vec)

            if max_value < current_product:
                max_value = current_product
                from_idx = j
                to_idx = i - j
                times = current_times
            elif max_value == current_product and times > current_times:
                max_value = current_product
                from_idx = j
                to_idx = i - j
                times = current_times

        if max_value == i:
            money[i].price = i
            money[i].vec.append(i)
        else:
            money[i].price = money[from_idx].price * money[to_idx].price
            money[i].vec.extend(money[from_idx].vec)
            money[i].vec.extend(money[to_idx].vec)

    print(" ".join(map(str, money[nums].vec)))


if __name__ == "__main__":
    main()
