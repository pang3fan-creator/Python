# 输入获取
flaw = int(input())
s = input()


# 算法入口
def getResult():
    yuanSet = set(list("aeiouAEIOU"))

    idxs = []
    for i in range(len(s)):
        if s[i] in yuanSet:
            idxs.append(i)

    ans = 0

    l = 0
    r = 0

    while r < len(idxs):
        # 瑕疵度计算
        diff = idxs[r] - idxs[l] - (r - l)

        if diff > flaw:
            l += 1
        elif diff < flaw:
            r += 1
        else:
            ans = max(ans, idxs[r] - idxs[l] + 1)
            r += 1

    return ans


# 算法调用
print(getResult())
