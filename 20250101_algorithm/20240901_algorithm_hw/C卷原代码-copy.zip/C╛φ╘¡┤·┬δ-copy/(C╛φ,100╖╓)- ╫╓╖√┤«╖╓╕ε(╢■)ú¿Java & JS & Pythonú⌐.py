# 输入获取
k = int(input())
s = input()


def convert(s):
    lowerCount = 0
    upperCount = 0

    for c in s:
        if 'z' >= c >= 'a':
            lowerCount += 1
        elif 'Z' >= c >= 'A':
            upperCount += 1

    if lowerCount > upperCount:
        return s.lower()
    elif lowerCount < upperCount:
        return s.upper()
    else:
        return s


# 算法入口
def getResult():
    arr = s.split("-")

    ans = []
    # ans.append(convert(arr[0])) # 看用例说明，对应第一个子串是不需要做大小写转换的，但是也拿不准，考试时可以都试下
    ans.append(arr[0])

    # 剩余子串重新合并为一个新字符串，每k个字符一组
    newStr = "".join(arr[1:])
    for i in range(0, len(newStr), k):
        subStr = newStr[i:i + k]
        # 子串中小写字母居多，则整体转为小写字母，大写字母居多，则整体转为大写字母
        ans.append(convert(subStr))

    return "-".join(ans)


# 算法调用
print(getResult())