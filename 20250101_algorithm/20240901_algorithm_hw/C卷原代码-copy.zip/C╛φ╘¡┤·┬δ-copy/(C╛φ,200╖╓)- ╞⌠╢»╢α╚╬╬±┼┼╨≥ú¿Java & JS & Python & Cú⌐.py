# 输入获取
relations = list(map(lambda s: s.split("->"), input().split()))


# 算法入口
def getResult():
    inDegree = {}
    next = {}

    # a依赖b, 即b执行完，才能执行a
    for a, b in relations:
        # b的入度不变
        inDegree[b] = inDegree.get(b, 0)
        # a的入度+1
        inDegree[a] = inDegree.get(a, 0) + 1

        # b的后继节点集合添加a
        next[b] = next.get(b, [])
        next[b].append(a)

        # a的后继节点集合不变
        next[a] = next.get(a, [])

    # queue收集第一层入度为0的点
    queue = []
    for task in inDegree:
        if inDegree[task] == 0:
            queue.append(task)

    # 记录任务执行的顺序
    ans = []

    while len(queue) > 0:
        # 如果同时有多个任务要执行，则根据任务名称字母顺序排序
        queue.sort()

        # newQueue用于记录下一层入度为0的点
        newQueue = []
        for fa in queue:
            # fa执行，则加入已完成的任务列表
            ans.append(fa)

            for ch in next[fa]:
                # fa是父任务，ch是子任务, 即fa执行完，才能执行ch
                # fa执行完，则对应ch的入度-1
                inDegree[ch] -= 1

                # 如果ch的入度变为0，则加入新一层入度0的点集
                if inDegree[ch] == 0:
                    newQueue.append(ch)

        queue = newQueue

    return " ".join(ans)


# 算法调用
print(getResult())
