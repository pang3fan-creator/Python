# 输入获取
t = int(input())


# 算法入口
def getResult():
    arr = [i + 1 for i in range(t)]

    ans = []

    l = 0
    r = 1
    total = arr[l]

    while l < t:
        if total > t:
            total -= arr[l]
            l += 1
        elif total == t:
            ans.append(arr[l:r])
            total -= arr[l]
            l += 1
            if r >= t:
                break
            else:
                total += arr[r]
                r += 1
        else:
            total += arr[r]
            r += 1

    ans.sort(key=lambda x: len(x))

    for an in ans:
        print(f"{t}={'+'.join(map(str, an))}")

    print(f"Result:{len(ans)}")


# 算法调用
getResult()
