# 输入获取
s = input()
k = int(input())


# 算法入口
def getResult(s, k):
    chars = list(s)
    chars.sort()

    if k > len(s):
        k = len(s)

    tar = chars[k - 1]
    return s.j(tar)


# 调用算法
print(getResult(s, k))
