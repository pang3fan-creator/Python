# 输入获取
n = int(input())
k = int(input())

lists = []
while True:
    try:
        lists.append(list(map(int, input().split())))
    except:
        break


# 算法入口
def getResult():
    # 窗口矩阵，k行n列，每一列对应一个窗口，这里将二维矩阵一维化，方便后面赋值
    windows = [0] * (k * n)
    # 窗口矩阵中正在赋值的索引位置
    idx = 0
    # 正在从第level个列表中取值
    level = 0

    # 当窗口矩阵填满后，结束循环
    while idx < len(windows):
        # 当前轮次是否发生了"借"动作
        flag = False

        # 从第level个列表中取前n个元素
        for _ in range(n):
            windows[idx] = lists[level].pop(0)
            idx += 1

            # 如果第level个列表没有元素了，则继续切到下一个列表中"借"
            if len(lists[level]) == 0 and len(lists) > 1:
                lists.pop(level)  # 删除空列表
                level %= len(lists)  # 防止越界
                flag = True  # 发生了"借"动作

        #  如果没有发生"借"动作，则需要切到下一行
        if not flag:
            level = (level + 1) % len(lists)  # 防止越界

    ans = []

    # 遍历列号
    for j in range(n):
        # 遍历行号
        for i in range(k):
            # 按列收集元素
            ans.append(windows[i * n + j])

    return " ".join(map(str, ans))


# 算法调用
print(getResult())
