# 输入获取
n = int(input())  # 明文数字个数
datas = list(map(int, input().split()))  # 明文

m = int(input())  # 密码本矩阵大小
secrets = []  # 密码本

# 记录密码本中元素值等于“明文第一个数字”的所有元素的位置
starts = []

for i in range(m):
    secrets.append(list(map(int, input().split())))
    for j in range(m):
        # 如果密码本(i,j)位置元素指等于明文第一个数字值，则记录(i,j)作为一个出发位置
        if secrets[i][j] == datas[0]:
            starts.append((i, j))

# 上，左，右，下偏移量，注意这里的顺序是有影响的，即下一步偏移后产生的密文的字符序必然是：上 < 左 < 右 < 下
offsets = ((-1, 0), (0, -1), (0, 1), (1, 0))


def dfs(x, y, index, path, used):
    """
    :param x: 当前位置横坐标
    :param y: 当前位置纵坐标
    :param index: datas[index]是将要匹配的明文数字
    :param path: 路径
    :param used: 密码本各元素使用情况
    :return: 是否找到符合要求的路径
    """
    if index == n:
        # 已找到明文最后一个数字，则找到符合要求的路径
        return True

    # 否则，进行上、左、右、下四个方向偏移，注意这里的顺序是有影响的，即下一步偏移后产生的密文的字符序必然是：上 < 左 < 右 < 下
    for offsetX, offsetY in offsets:
        # 新位置
        newX = x + offsetX
        newY = y + offsetY

        # 新位置越界，或者新位置已使用，或者新位置不是目标值，则跳过
        if newX < 0 or newX >= m or newY < 0 or newY >= m or used[newX][newY] or secrets[newX][newY] != datas[index]:
            continue

        # 递归进入新位置
        path.append(f"{newX} {newY}")
        used[newX][newY] = True

        # 如果当前分支可以找到符合要求的路径，则返回
        if dfs(newX, newY, index + 1, path, used):
            return True

        # 否则，回溯
        used[newX][newY] = False
        path.pop()

    return False


# 算法入口
def getResult():
    # 出发位置(x,y)
    for x, y in starts:
        # used[i][j]用于记录密码本(i,j)元素是否已使用
        used = [[False] * m for _ in range(m)]
        # 出发点位置元素已使用
        used[x][y] = True

        # 记录结果路径各节点位置
        # 出发点位置记录
        path = [f"{x} {y}"]

        # 开始深搜
        if dfs(x, y, 1, path, used):
            return " ".join(path)

    return "error"


# 算法调用
print(getResult())
