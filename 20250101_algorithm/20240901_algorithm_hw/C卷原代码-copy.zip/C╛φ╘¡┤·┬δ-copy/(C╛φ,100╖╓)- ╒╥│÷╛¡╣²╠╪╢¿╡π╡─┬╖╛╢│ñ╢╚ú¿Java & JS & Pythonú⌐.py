import sys

# 输入获取
all = input()
must = input()


def dfs(index, must, mustCharIdx, path, ans):
    if len(path) == len(must):
        dis = path[0]  # 运动起点必须从第一行输入all的第一个字母开始
        # dis = 0  # 运动起点从all中must第一个字母位置开始

        for i in range(1, len(path)):
            dis += abs(path[i] - path[i - 1])

        ans[0] = min(ans[0], dis)
        return

    for idx in mustCharIdx[must[index]]:
        path.append(idx)
        dfs(index + 1, must, mustCharIdx, path, ans)
        path.pop()


def getResult(all, must):
    mustCharIdx = {}

    mustChar = set(must)

    for i in range(len(all)):
        c = all[i]

        if c in mustChar:
            if mustCharIdx.get(c) is None:
                mustCharIdx[c] = []
            mustCharIdx[c].append(i)

    ans = [sys.maxsize]
    dfs(0, must, mustCharIdx, [], ans)
    return ans[0]


print(getResult(all, must))
