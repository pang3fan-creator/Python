# 输入获取
nums = list(map(int, input().split(",")))

# 2 可以当作 5 来使用，5 也可以当作 2 来使用进行数字拼接
# 6 可以当作 9 来使用，9 也可以当作 6 来使用进行数字拼接
mapping = {2: 5, 5: 2, 6: 9, 9: 6}


# 排列求解
def dfs(vis, path, res):
    if len(path) > 0:
        res.append(int("".join(map(str, path))))

    if len(path) == len(nums):
        return

    for i in range(len(nums)):
        if vis[i]:
            continue

        vis[i] = True

        path.append(nums[i])
        dfs(vis, path, res)
        path.pop()

        # 2 可以当作 5 来使用，5 也可以当作 2 来使用进行数字拼接
        # 6 可以当作 9 来使用，9 也可以当作 6 来使用进行数字拼接
        if nums[i] in mapping:
            path.append(mapping[nums[i]])
            dfs(vis, path, res)
            path.pop()

        vis[i] = False


# 算法入口
def solution():
    for num in nums:
        # 输入的数字不在范围内
        if num < 1 or num > 9:
            return -1

    setNums = set(nums)

    # 输入的数字有重复
    if len(setNums) != 4:
        return -1

    # 屏幕不能同时给出 2 和 5
    if 2 in setNums and 5 in setNums:
        return -1

    # 屏幕不能同时给出 6 和 9
    if 6 in setNums and 9 in setNums:
        return -1

    vis = [False] * len(nums)
    path = []
    res = []  # 记录排列

    # 排列求解
    dfs(vis, path, res)

    # 给出这几个数字可拼成的数字从小到大排列位于第N位置的数字
    res.sort()

    # N为给出数字中最大的，如果不到这么多数字则给出最后一个即可
    n = min(max(nums), len(res))
    return res[n - 1]


# 算法调用
print(solution())
