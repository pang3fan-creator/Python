# 输入获取
n = int(input())
arr = list(map(int, input().split()))
m = int(input())


# 算法入口
def getResult():
    sumV = sum(arr[:m])
    ans = sumV

    for i in range(1, n-m+1):
        sumV += arr[i+m-1] - arr[i-1]
        ans = max(ans, sumV)

    return ans


# 算法调用
print(getResult())