# 输入获取
operates = input().split()
n, m = map(int, input().split())
matrix = [input().split() for _ in range(n)]

# 记录蛇各个部分位置
snake = []
# 蛇头移动初始向左 [行偏移量，列偏移量]，向左即列位置-1
offset = [0, -1]


# 坐标类
class Pos:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y


# 算法入口
def getResult():
    # 找到初始蛇头位置，并使用snake[0]来维护蛇头位置
    for i in range(n):
        for j in range(m):
            if "H" == matrix[i][j]:
                snake.append(Pos(i, j))

    for op in operates:
        if op == "U":
            offset[0] = -1
            offset[1] = 0
        elif op == "D":
            offset[0] = 1
            offset[1] = 0
        elif op == "L":
            offset[0] = 0
            offset[1] = -1
        elif op == "R":
            offset[0] = 0
            offset[1] = 1
        elif op == "G":
            head = snake[0]
            head_next = Pos(head.x + offset[0], head.y + offset[1])

            if head_next.x < 0 or head_next.x >= n or head_next.y < 0 or head_next.y >= m:
                return len(snake)

            tail = snake[-1]

            cell = matrix[head_next.x][head_next.y]
            if cell == "E":
                # 如果蛇头去的地方是空地，则:
                # 蛇身的每个位置都递进为前面一个位置，蛇尾巴位置恢复为空地
                matrix[tail.x][tail.y] = "E"
                snake.pop()
                # 蛇头进入新位置
                matrix[head_next.x][head_next.y] = "H"
                snake.insert(0, head_next)
            elif cell == "F":
                # 如果蛇头去的地方是食物，则蛇身长度增加一，相当于蛇身各部分位置不变，蛇头变到当前去的位置
                matrix[head_next.x][head_next.y] = "H"
                snake.insert(0, head_next)
            elif cell == "H":
                # 如果蛇头去的地方是蛇尾，则由于递进关系，蛇头是吃不到蛇尾的
                if head_next == tail:
                    snake.insert(0, snake.pop())
                else:
                    # 如果蛇头去的地方是蛇身，则会吃到自己
                    return len(snake)

    return len(snake)


# 算法调用
print(getResult())
