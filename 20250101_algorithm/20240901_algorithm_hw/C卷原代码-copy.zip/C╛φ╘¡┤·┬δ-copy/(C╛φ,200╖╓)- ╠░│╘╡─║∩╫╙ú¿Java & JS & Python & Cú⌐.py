# 输入获取
length = int(input())
nums = list(map(int, input().split()))
n = int(input())


# 算法入口
def getResult():
    # 初始时，左边选择0个，因此左边选择的香蕉数为 0
    leftSum = 0
    # 初始时，右边选择n个，因此右边选择的香蕉数为 nums[len-n] ~ nums[len - 1] 这个n个元素之和
    rightSum = sum(nums[length - n:])

    # 如果选择数n == len，即全选，此时直接返回初始rightSum
    if length == n:
        return rightSum

    # 如果不是全选
    # sum记录当前选择结果
    sumV = leftSum + rightSum
    # ans记录所有选择结果中最大的
    ans = sumV

    # l指向左边将要获得的，即左边获得一个
    l = 0
    # r指向右边将要失去的，即右边失去一个
    r = length - n

    while l < n:
        sumV += nums[l] - nums[r]
        ans = max(ans, sumV)
        l += 1
        r += 1

    return ans


# 算法调用
print(getResult())
