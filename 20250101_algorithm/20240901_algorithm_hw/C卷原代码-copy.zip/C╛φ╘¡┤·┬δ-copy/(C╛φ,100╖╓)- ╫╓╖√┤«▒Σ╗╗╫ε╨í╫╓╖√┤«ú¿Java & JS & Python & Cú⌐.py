# 输入获取
s = input()


# 算法入口
def getResult():
    minSArr = list(s)
    minSArr.sort()

    if s == "".join(minSArr):
        return s

    sArr = list(s)

    for i in range(len(s)):
        if sArr[i] != minSArr[i]:
            tmp = sArr[i]
            sArr[i] = minSArr[i]

            swapIdx = s.rindex(minSArr[i])
            sArr[swapIdx] = tmp
            break

    return "".join(sArr)


# 调用算法
print(getResult())