# 输入获取
total = int(input())
arr = list(map(int, input().split()))
n = int(input())


# 算法入口
def getResult():
    arr.sort()

    ans = 0
    for i in range(total):
        for j in range(total - 1, i, -1):
            sumV = arr[i] + arr[j]

            if sumV == n:
                ans += 1
            elif sumV < n:
                break

    return ans


# 算法调用
print(getResult())