# 输入获取
n, m = map(int, input().split())
matrix = [list(map(int, input().split())) for i in range(n)]


class Pos:
    def __init__(self, x, y, pre):
        self.x = x  # 当前点的横坐标
        self.y = y  # 当前点的纵坐标
        self.pre = pre  # 当前点的上一个点（此属性用于形成路径链）


def printPath(cur):
    # 这里采用递归打印，保证打印顺序是起点到终点
    if cur.pre:
        # 递归的作用是优先打印pre点，pre点打印完，回溯打印cur点
        printPath(cur.pre)

    print(f"({cur.x},{cur.y})")


# 算法入口
def getResult():
    # 广搜队列
    queue = []

    # 将（0，0）位置标记为“走过状态”，即将元素值设为2
    matrix[0][0] = 2
    # 将走过的点加入队列
    queue.append(Pos(0, 0, None))

    # 上下左右偏移量
    offsets = ((-1, 0), (1, 0), (0, -1), (0, 1))

    # 广搜
    while len(queue) > 0:
        # 当前点
        cur = queue.pop(0)

        # 遍历当前点的上、下、左、右方向的新点
        for offsetX, offsetY in offsets:
            # 新点的坐标
            newX = cur.x + offsetX
            newY = cur.y + offsetY

            # 如果新点不越界，且未被访问过，且不是墙， 则新点可以访问
            if n > newX >= 0 and m > newY >= 0 and matrix[newX][newY] == 0:
                # 将新点状态设为走过
                matrix[newX][newY] = 2
                # 将新点和上一个点关联，形成路径链
                nxt = Pos(newX, newY, cur)
                queue.append(nxt)

                # 如果新点就是终点，那么则说明找到了起点到终点的路径
                if newX == n - 1 and newY == m - 1:
                    # 打印路径
                    printPath(nxt)
                    # 结束查找
                    return


# 算法调用
getResult()
