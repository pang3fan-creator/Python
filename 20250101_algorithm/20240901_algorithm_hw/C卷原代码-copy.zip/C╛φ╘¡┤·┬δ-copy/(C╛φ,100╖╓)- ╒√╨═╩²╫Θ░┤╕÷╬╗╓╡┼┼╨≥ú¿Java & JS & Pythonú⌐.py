# 输入获取
arr = input().split(",")


# 算法入口
def getResult():
    arr.sort(key=lambda x: x[-1])
    return ",".join(arr)


# 算法调用
print(getResult())
