# 输入获取
maxCount = int(input())
n = int(input())
tasks = list(map(int, input().split()))


# 算法入口
def getResult():
    time = 0
    remain = 0

    for task in tasks:
        if task + remain > maxCount:
            remain = task + remain - maxCount
        else:
            remain = 0
        time += 1

    while remain > 0:
        remain -= maxCount
        time += 1

    return time


# 算法调用
print(getResult())
