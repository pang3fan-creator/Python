# 输入获取
m = int(input())

tasks = [[] for _ in range(m)]

for i in range(m):
    n = int(input())
    task = [[] for _ in range(n)]
    for j in range(n):
        task[j] = list(map(int, input().split()))
    tasks[i] = task


# 算法入口
def getResult():
    for task in tasks:
        # 将每个任务中的机器工作顺序，按照运行时间降序排序
        task.sort(key=lambda x: -x[1])

        config_endTime = 0
        ans = 0

        for config_cost, run_cost in task:
            config_endTime += config_cost
            ans = max(ans, config_endTime + run_cost)

        print(ans)

# 算法调用
