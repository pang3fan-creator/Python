# 输入获取
str = input()
subStr = input()


# 算法入口
def getResult():
    if len(str) < len(subStr):
        return "No"

    idx = str.find(subStr)
    if idx == -1:
        return "No"
    else:
        return idx + 1


# 算法调用
print(getResult())
