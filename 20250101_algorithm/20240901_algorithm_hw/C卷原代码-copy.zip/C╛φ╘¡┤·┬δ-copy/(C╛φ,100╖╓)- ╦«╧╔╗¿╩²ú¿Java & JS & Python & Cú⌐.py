import math

# 输入获取
n = int(input())
m = int(input())


# 算法入口
def getResult():
    # 若输入不合法，返回-1
    if n < 3 or n > 7 or m < 0:
        return -1

    # 提前计算好0~9的N次方, 避免后续进行重复计算
    powN = {}
    for i in range(10):
        powN[str(i)] = int(math.pow(i, n))

    # 最小的N位数
    minV = int(math.pow(10, n - 1))
    # 最大的N位数
    maxV = int(math.pow(10, n))

    # 记录当前水仙花数
    ans = 0

    # 记录当前水仙花数是第几个
    idx = 0

    for num in range(minV, maxV):
        # 记录num各位数字的N次方之和
        sumV = 0

        # 遍历num的每一位数字
        for c in str(num):
            sumV += powN[c]

        # 判断num是否为水仙花数
        if sumV == num:
            ans = num

            # 如果num刚好是N位数的第m个水仙花数，则直接返回，否则继续查找
            if idx == m:
                return ans

            idx += 1

    # 若m大于水仙花数的个数，返回最后一个水仙花数和m的乘积
    return ans * m


# 算法调用
print(getResult())
