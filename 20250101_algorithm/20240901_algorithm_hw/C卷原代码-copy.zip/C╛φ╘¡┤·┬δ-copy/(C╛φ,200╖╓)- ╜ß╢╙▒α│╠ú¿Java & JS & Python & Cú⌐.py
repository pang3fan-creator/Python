class Node:
    def __init__(self, idx, val):
        self.idx = idx
        self.val = val
        self.left = None
        self.right = None
        self.count = 0


def insertNode(root, node, res):
    if root is None:
        return node

    if node.val < root.val:
        root.count += 1
        root.left = insertNode(root.left, node, res)
    else:
        res[node.idx] += root.count + 1
        root.right = insertNode(root.right, node, res)

    return root


# 输入获取
n = int(input())
levels = list(map(int, input().split()))


# 算法入口
def getResult():
    root = None

    rightSmaller = [0] * n
    for i in range(n - 1, -1, -1):
        root = insertNode(root, Node(i, levels[i]), rightSmaller)

    levels.reverse()
    root = None

    leftSmaller = [0] * n
    for i in range(n - 1, -1, -1):
        root = insertNode(root, Node(i, levels[i]), leftSmaller)
    leftSmaller.reverse()

    total = 0
    for i in range(n):
        leftSmallerCount = leftSmaller[i]
        leftBiggerCount = i - leftSmallerCount

        rightSmallerCount = rightSmaller[i]
        rightBiggerCount = n - i - 1 - rightSmallerCount

        total += leftSmallerCount * rightBiggerCount + leftBiggerCount * rightSmallerCount

    return total


# 算法调用
print(getResult())
