# 输入获取
commands = list(map(int, input().split()))


# 算法入口
def getResult():
    screen = []
    clip = []
    isSelect = False

    for command in commands:
        if command == 1:
            if isSelect:
                screen.clear()
            screen.append("a")
            isSelect = False
        elif command == 2:
            if isSelect:
                clip.clear()
                clip.extend(screen)
        elif command == 3:
            if isSelect:
                clip.clear()
                clip.extend(screen)
                screen.clear()
                isSelect = False
        elif command == 4:
            if isSelect:
                screen.clear()
            screen.extend(clip)
            isSelect = False
        elif command == 5:
            if len(screen) != 0:
                isSelect = True

    return len(screen)


# 调用算法
print(getResult())
