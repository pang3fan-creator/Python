import sys

# 输入获取
n, m = map(int, input().split())
lights = [list(map(int, input().split())) for _ in range(n)]
timePerRoad = int(input())
rowStart, colStart = map(int, input().split())
rowEnd, colEnd = map(int, input().split())

offsets = ((-1, 0), (1, 0), (0, -1), (0, 1))
visited = [[False] * m for _ in range(n)]


# 根据三点坐标，确定拐弯方向
def getDirection(preX, preY, curX, curY, nextX, nextY):
    """
    :param preX: 前一个点横坐标
    :param preY: 前一个点纵坐标
    :param curX: 当前点横坐标
    :param curY: 当前点纵坐标
    :param nextX: 下一个点横坐标
    :param nextY: 下一个点纵坐标
    :return: cur到next的拐弯方向， >0 表示向左拐， ==0 表示直行（含调头）， <0 表示向右拐
    """
    # 向量 pre->cur
    dx1 = curX - preX
    dy1 = curY - preY

    # 向量 cur->next
    dx2 = nextX - curX
    dy2 = nextY - curY

    #  两个向量的叉积 >0 表示向左拐， ==0 表示直行（含调头）， <0 表示向右拐
    return dx1 * dy2 - dx2 * dy1


# 暴力搜索
def dfs(curX, curY, preX, preY, cost, minCost):
    """
    :param curX: 当前位置横坐标
    :param curY: 当前位置纵坐标
    :param preX: 上一个位置横坐标
    :param preY: 上一个位置纵坐标
    :param cost: 到达当前位置花费的时间
    :param minCost: 记录起点到终点的最小花费时间
    """
    # 如果到达当前前花费的时间cost 达到了 已知minCost，那么后续路径就没必要探索了，因为必然要比minCost大
    if cost >= minCost[0]:
        return

    # 如果当前点是终点，且花费的时间cost更少，则更新minCost
    if curX == rowEnd and curY == colEnd:
        minCost[0] = cost
        return

    # 否则，从当前位置的四个方向继续探索路径
    for offsetX, offsetY in offsets:
        # 新位置
        nextX = curX + offsetX
        nextY = curY + offsetY

        # 新位置越界或者已经访问过，则不能访问，继续其他方向探索
        if nextX < 0 or nextX >= n or nextY < 0 or nextY >= m or visited[nextX][nextY]:
            continue

        # 标记新位置访问过
        visited[nextX][nextY] = True

        # 根据pre,cur,next三点，判断拐弯方向
        direction = getDirection(preX, preY, curX, curY, nextX, nextY)

        # cur到达next位置必须要增加timePreRoad个时间
        increment = timePerRoad
        # preX=-1, preY=-1 表示pre位置不存在，此时探索下一个位置不需要花费等待周期
        if preX >= 0 and preY >= 0 and direction >= 0:
            # pre位置存在，且cur->next是左拐或者直行，则需要增加当前位置对应的等待周期时间
            increment += lights[curX][curY]

        # 递归进入新位置
        dfs(nextX, nextY, curX, curY, cost + increment, minCost)

        # 回溯
        visited[nextX][nextY] = False


# 算法入口
def getResult():
    visited[rowStart][colStart] = True

    minCost = [sys.maxsize]
    dfs(rowStart, colStart, -1, -1, 0, minCost)

    return minCost[0]


# 算法调用
print(getResult())
