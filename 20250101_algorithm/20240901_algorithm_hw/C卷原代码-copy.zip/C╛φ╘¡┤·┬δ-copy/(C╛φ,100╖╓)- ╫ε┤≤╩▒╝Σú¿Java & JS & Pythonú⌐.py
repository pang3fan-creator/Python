import re

# 输入获取
arr = eval(input())

p = re.compile("(([01][0-9])|([2][0-3]))([0-5][0-9])([0-5][0-9])")


def dfs(arr, used, path, res):
    if len(path) == len(arr):
        tmp = "".join(map(str, path))
        if p.match(tmp):
            res.append(path[:])
        return

    for i in range(len(arr)):
        if not used[i]:
            path.append(arr[i])
            used[i] = True
            dfs(arr, used, path, res)
            used[i] = False
            path.pop()


# 算法入口
def getResult():
    res = []
    dfs(arr, [False] * (len(arr)), [], res)

    if len(res) == 0:
        return "invalid"

    res.sort()
    t = res[-1]

    return f"{t[0]}{t[1]}:{t[2]}{t[3]}:{t[4]}{t[5]}"


# 算法调用
print(getResult())
