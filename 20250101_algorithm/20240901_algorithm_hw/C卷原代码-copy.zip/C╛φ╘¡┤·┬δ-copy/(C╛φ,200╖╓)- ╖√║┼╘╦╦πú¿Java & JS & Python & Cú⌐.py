# 输入获取
s = input()

# 操作数栈
oper_num = []
# 操作符栈
oper_sign = []


# 分数类
class Fractions:
    def __init__(self, fa, ch):
        self.fa = fa  # 分母
        self.ch = ch  # 分子


# 辗转相除法，求两个数的最大公约数
def getMaxCommonDivisor(x, y):
    while y != 0:
        tmp = y
        y = x % y
        x = tmp

    return x


# 取出oper_num栈顶两个操作数进行运算
def calc():
    # 操作数顺序会对运算产生影响
    b = oper_num.pop()  # 栈顶元素是运算符右边的操作数
    a = oper_num.pop()  # 栈顶倒数第二个元素是运算符左边的操作数

    # 运算符
    op = oper_sign.pop()

    # 记录运算结果
    result = Fractions(None, None)

    if op == '+':
        result.fa = a.fa * b.fa
        result.ch = a.ch * b.fa + b.ch * a.fa
    elif op == '-':
        result.fa = a.fa * b.fa
        result.ch = a.ch * b.fa - b.ch * a.fa
    elif op == '*':
        result.fa = a.fa * b.fa
        result.ch = a.ch * b.ch
    elif op == '/':
        result.fa = a.fa * b.ch
        result.ch = a.ch * b.fa

    oper_num.append(result)


def getResult():
    # +,-,*,/ 运算符优先级
    priority = {
        "+": 1,
        "-": 1,
        "*": 2,
        "/": 2
    }

    # 操作数的字符缓存容器
    numStr = []

    i = 0
    while i < len(s):
        c = s[i]

        # 遇到数字字符
        if '9' >= c >= '0':
            # 则将该数字所在操作数的剩余数字字符一次性探索完
            while '9' >= c >= '0':
                numStr.append(c)
                if i + 1 >= len(s):
                    break
                i += 1
                c = s[i]

            # 探索完后，将操作数缓存容器中记录的字符，变为分数后，压入操作数栈
            oper_num.append(Fractions(1, int("".join(numStr))))
            # 注意清空操作数缓存容器
            numStr.clear()

        # 遇到运算符
        if c == '+' or c == '-' or c == '*' or c == '/':
            # 只要栈顶运算符的优先级 >= 当前运算符，就需要不停出栈运算
            while len(oper_sign) > 0 and oper_sign[-1] != '(' and priority[c] <= priority[oper_sign[-1]]:
                calc()
            oper_sign.append(c)
        elif c == ')':
            # 遇到')', 需要将操作符栈中靠近栈顶的'('后面的运算都出栈做了
            while oper_sign[-1] != '(':
                calc()
            # 最后将')'对应的'('出栈
            oper_sign.pop()
        elif c == '(':
            # 遇到'('，则直接压倒操作符栈
            oper_sign.append(c)

        i += 1

    # oper_num栈中还有2个以上的数，则还需要进行运算
    while len(oper_num) > 1:
        calc()

    # oper_num栈中只剩一个数时，该数就是表达式结果
    result = oper_num.pop()

    # 如果结果的分母为0（除数为0），则不合法
    if result.fa == 0:
        return "ERROR"

    # 求分子、分母的最大公约数，并进行约份，求得最简格式的分子，分母
    k = getMaxCommonDivisor(result.fa, result.ch)
    result.fa //= k
    result.ch //= k

    # 求计算结果的符号，这里用乘法是为了避免 分母小，分子大，除法结果为0的情况，这样会丢失符号信息
    sign = "-" if result.fa * result.ch < 0 else ""

    fa = abs(result.fa)
    ch = abs(result.ch)

    if fa == 1:
        #  如果分母为1，则直接输出分子
        return f"{sign}{ch}"
    else:
        # 如果分母不为1，则输出 分子 / 分母
        return f"{sign}{ch}/{fa}"


# 算法调用
print(getResult())
