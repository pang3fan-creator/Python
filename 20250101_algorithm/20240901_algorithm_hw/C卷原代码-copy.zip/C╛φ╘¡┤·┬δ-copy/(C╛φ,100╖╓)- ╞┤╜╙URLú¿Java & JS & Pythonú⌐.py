# 输入获取
prefix, suffix = input().split(",")

prefix = prefix.rstrip("/")
suffix = suffix.lstrip("/")

print(prefix + "/" + suffix)
