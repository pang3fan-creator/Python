n = int(input())
wealth = list(map(int, input().split()))

# 这里头插一个0，是为了让wealth数组索引对应成员编号 1~N
wealth.insert(0, 0)

family = []
family.extend(wealth)

for _ in range(n - 1):
    fa, ch = map(int, input().split())
    family[fa] += wealth[ch]

print(max(family))
