import sys

# 输入获取
n = int(input())
res = [list(map(int, input().split())) for _ in range(n)]


def getMinEleIdx(arr, excludeIdx):
    minEleVal = sys.maxsize
    minEleIdx = -1

    for i in range(len(arr)):
        if i == excludeIdx:
            continue

        if arr[i] <= minEleVal:
            minEleVal = arr[i]
            minEleIdx = i

    return minEleIdx


# 算法入口
def getResult():
    last = -1
    total = 0

    for i in range(n):
        last = getMinEleIdx(res[i], last)
        total += res[i][last]

    return total


# 算法调用
print(getResult())
