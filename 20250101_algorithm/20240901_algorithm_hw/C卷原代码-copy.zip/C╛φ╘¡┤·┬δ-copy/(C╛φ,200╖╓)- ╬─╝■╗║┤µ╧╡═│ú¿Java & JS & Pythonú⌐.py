# 双向链表节点
class Node:
    def __init__(self, key, val, freq):
        """
        :param key: 记录本题的键
        :param val: 记录本题的值
        :param freq: 记录该键被访问的次数
        """
        self.key = key
        self.val = val
        self.freq = freq
        self.prev = None
        self.next = None


# 双向链表
class Link:
    def __init__(self):
        self.size = 0
        self.head = None
        self.tail = None

    def addLast(self, node):
        """
        尾插
        :param node: 要被插入的节点
        """
        if self.size == 0:
            # 空链表，则node节点插入后，即为头、尾节点
            self.head = node
            self.tail = node
        else:
            # 非空链表，则node节点插入到tail节点后面
            self.tail.next = node
            node.prev = self.tail
            self.tail = node

        self.size += 1

    def remove(self, node):
        """
        删除指定节点
        :param node: 要删除的节点
        """
        if self.size == 0:
            # 空链表没有节点，所以无法删除
            return

        if self.size == 1:
            # 链表只有一个节点，则删除完后，变为空链表
            self.head = None
            self.tail = None
        elif self.head == node:
            # 如果要删除的节点是头节点
            self.head = self.head.next
            self.head.prev = None
        elif self.tail == node:
            # 如果要删除的节点是尾节点
            self.tail = self.tail.prev
            self.tail.next = None
        else:
            # 如果要删除的节点是中间节点
            node.prev.next = node.next
            node.next.prev = node.prev

        self.size -= 1


# LFU缓存
class LFUCache:
    def __init__(self, capacity):
        self.keyMap = {}  # keyMap用于记录key对应的node
        self.freqMap = {}  # freqMap的key是访问次数，value是具有相同访问次数的key对应的node组成的链表，链表头是最远访问的，链表尾是最近访问的
        self.capacity = capacity  # LFU缓存中能记录的最多key的数量
        self.minFreq = 0  # LFU缓存中所有的key中最少的访问次数

    def get(self, key):
        # 如果文件不存在，则不作任何操作。
        if key not in self.keyMap:
            return

        # 每次文件访问后，总访问次数加1，最近访问时间更新到最新时间
        node = self.keyMap[key]
        self.incNodeFreq(node)

    def put(self, key, val):
        # 如果新文件的文件名和文件缓存中已有的文件名相同，则不会放在缓存中
        if key in self.keyMap:
            return

        # 当缓存空间不足以存放新的文件时，根据规则删除文件，直到剩余空间满足新的文件大小位置，再存放新文件。
        while self.capacity < val:
            if self.minFreq == 0:
                # 文件系统空了，也放不下该文件，则不放入
                return

            # 找出最少访问次数对应的链表
            minFreqLink = self.freqMap[self.minFreq]

            # 链表头部节点是最少访问次数中，最远访问的文件，我们需要删除它
            removeNode = minFreqLink.head
            # 删除对应文件后，文件系统容量新增
            self.capacity += removeNode.val

            # 执行删除操作，freqMap和keyMap都要删除掉对应文件的记录
            minFreqLink.remove(removeNode)
            self.keyMap.pop(removeNode.key)

            # 如果删除后，最少访问次数的链表空了，则需要找到下一个最少访问次数的链表
            if minFreqLink.size == 0:
                # 最少次数的链表空了，则删除对应最少次数的记录
                del self.freqMap[self.minFreq]

                # 更新最少次数
                if len(self.freqMap.keys()) > 0:
                    self.minFreq = min(self.freqMap.keys())
                else:
                    # 文件系统没有缓存文件了，则最少次数为0，表示文件系统空了
                    self.minFreq = 0

        # 新增文件，则文件系统容量减少
        self.capacity -= val
        # 新增文件的访问次数为1，因此最少访问次数变为了1
        self.minFreq = 1
        node = Node(key, val, self.minFreq)
        # 执行新增操作，freqMap和keyMap都要新增对应文件的记录
        self.freqMap.setdefault(self.minFreq, Link())
        self.freqMap.get(self.minFreq).addLast(node)
        self.keyMap[key] = node

    def incNodeFreq(self, node):
        """
        增加key的访问次数
        :param node: key对应的node
        """
        # 由于key的访问次数增加，因此要从原访问次数的链表中删除
        self.freqMap[node.freq].remove(node)

        # 如果原链表删除当前key对应的节点后为空，且原链表对应的访问次数就是最少访问次数
        if self.freqMap[node.freq].size == 0:
            # 最少次数的链表空了，则删除对应最少次数的记录
            del self.freqMap[node.freq]

            # 则最少访问次数对应的key没有了，因此最少访问次数++（即当前key访问次数++后，当前key的访问次数还是最少访问次数）
            if node.freq == self.minFreq:
                self.minFreq += 1

        # 当前key访问次数++
        node.freq += 1

        # 将当前key对应的node转移到对应增加后的访问次数对应的链表尾部（最近访问）
        self.freqMap.setdefault(node.freq, Link())
        self.freqMap[node.freq].addLast(node)


# 输入获取
m = int(input())

lfu = LFUCache(m)

n = int(input())

for _ in range(n):
    operation = input().split()

    op = operation[0]
    fileName = operation[1]

    if "put" == op:
        fileSize = int(operation[2])
        lfu.put(fileName, fileSize)
    else:
        lfu.get(fileName)

if lfu.capacity == m:
    print("NONE")
else:
    ans = list(lfu.keyMap.keys())
    ans.sort()
    print(",".join(ans))
