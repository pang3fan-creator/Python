# 输入获取
m = int(input())
arr = list(map(int, input().split()))
n = int(input())


# 算法入口
def getResult(m, arr, n):
    # 你需要对数组进行去重
    arr = list(set(arr))

    # 最大N个数与最小N个数不能有重叠，如有重叠，输入非法返回-1
    if len(arr) < n * 2:
        return -1

    arr.sort()

    # 数组中数字范围[0, 1000]
    if arr[0] < 0 or arr[-1] > 1000:
        return -1

    # 最大N个数与最小N个数的和
    return sum(arr[:n]) + sum(arr[-n:])


# 算法调用
print(getResult(m, arr, n))
