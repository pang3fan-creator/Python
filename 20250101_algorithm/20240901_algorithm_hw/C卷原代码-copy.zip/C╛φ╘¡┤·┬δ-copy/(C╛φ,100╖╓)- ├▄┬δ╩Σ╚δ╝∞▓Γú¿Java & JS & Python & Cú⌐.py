# 输入获取
s = input()


# 算法入口
def getResult():
    stack = []

    for c in s:
        if c == '<':
            if len(stack) > 0:
                stack.pop()
        else:
            stack.append(c)

    upper = 0
    lower = 0
    number = 0
    non_letter_number = 0

    password = []
    for c in stack:
        password.append(c)

        if 'z' >= c >= 'a':
            lower += 1
        elif 'Z' >= c >= 'A':
            upper += 1
        elif '9' >= c >= '0':
            number += 1
        else:
            non_letter_number += 1

    if len(password) >= 8 and lower >= 1 and upper >= 1 and number >= 1 and non_letter_number >= 1:
        password.append(",true")
    else:
        password.append(",false")

    return "".join(password)


# 算法调用
print(getResult())