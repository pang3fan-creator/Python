# 输入获取
n = int(input())
arr = list(map(int, input().split()))


# 算法入口
def getResult():
    stack = []

    res = [0]*(len(arr))

    for i in range(len(arr)):
        ele = arr[i]

        while True:
            if len(stack) == 0:
                stack.append([ele, i])
                break

            peekEle, peekIndex = stack[-1]

            if ele > peekEle:
                res[peekIndex] = i
                stack.pop()
            else:
                stack.append([ele, i])
                break

    return " ".join(map(str, res))


# 算法调用
print(getResult())