import sys

# 设置递归深度
sys.setrecursionlimit(5000)

# 输入获取
m, n, k = map(int, input().split())

# 全局变量
ans = 0  # 记录题解
visited = set()  # 记录已访问过的位置，避免重复统计
offsets = ((-1, 0), (1, 0), (0, -1), (0, 1))  # 上下左右偏移量

digitSums = [0] * (max(m, n))  # digitSums数组的索引是原始数，值是原始数对应的数位和
for i in range(len(digitSums)):
    num = i
    while num > 0:
        digitSums[i] += num % 10
        num //= 10


# 深度优先搜索遍历矩阵
def dfs(x, y):
    # 如果对应位置越界，则不能进入
    if x < 0 or x >= m or y < 0 or y >= n:
        return

    #  如果对应位置已横坐标、纵坐标的数位和之和超过了k，则不能进入
    if digitSums[x] + digitSums[y] > k:
        return

    pos = x * n + y

    # 如果对应位置已访问过，则不能进入
    if pos in visited:
        return

    # 否则可以进入
    visited.add(pos)

    # 且获得黄金
    global ans
    ans += 1

    # 继续遍历上、下、左、右方向上的新位置继续深搜
    for offsetX, offsetY in offsets:
        newX = x + offsetX
        newY = y + offsetY
        dfs(newX, newY)


# 算法入口
dfs(0, 0)
print(ans)
