import sys

# 输入获取
m, n = map(int, input().split())
matrix = [list(map(int, input().split())) for i in range(m)]

# 最短距离矩阵
dist = [[sys.maxsize for _ in range(n)] for _ in range(m)]

# 八个方向的偏移量
offsets = ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1))


# 算法入口
def spfa():
    queue = [[0, 0]]
    dist[0][0] = matrix[0][0]

    while len(queue) > 0:
        x, y = queue.pop(0)

        for offsetX, offsetY in offsets:
            newX = x + offsetX
            newY = y + offsetY

            if m > newX >= 0 and n > newY >= 0:
                newDist = dist[x][y] + matrix[newX][newY]

                if matrix[newX][newY] == matrix[x][y] and matrix[newX][newY] >= 1:
                    newDist -= 1

                if newDist < dist[newX][newY]:
                    dist[newX][newY] = newDist
                    queue.append([newX, newY])

    return dist[m - 1][n - 1]


# 算法调用
print(spfa())
