# 输入获取
k = int(input())
s = input()


# 算法入口
def getResult():
    sArr = s.split("-")

    first = sArr[0]

    if len(sArr) == 1:
        return first

    tmp = list("".join(sArr[1:]).upper())
    for i in range(len(tmp)):
        if i % k == 0:
            tmp[i] = "-" + tmp[i]

    return first + "".join(tmp)


# 算法调用
print(getResult())