import sys

# 输入获取
n, m, k = map(int, input().split())
matrix = [list(map(int, input().split())) for _ in range(n)]


def dfs(i, kth, match, vis):
    # 列号 i 发起了配对请求

    # 遍历每一个行号j
    for j in range(m):
        # 如果当前行号j未被增广路探索过 && 当前行j列号i可以配对（如果行列号位置(i,j)对应矩阵元素值小于等于kth（第K大值），则可以配对）
        if not vis[j] and matrix[i][j] <= kth:
            vis[j] = True

            # 如果对应行号j未配对，或者，已配对但是配对的雷浩match[j]可以找到其他行号重新配对
            if match[j] == -1 or dfs(match[j], kth, match, vis):
                # 则当前列号i 和 行号j 可以配对
                match[j] = i
                return True

    return False


def check(kth):
    # 利用二分图最大匹配来求解，小于等于kth（第K大值）的元素个数（即二分图最大匹配）
    smallerCount = 0

    # 记录每个行号的匹配成功的列号
    # 初始时每个行号都处于未配对状态，此时将行号配对的列号赋值为-1
    match = [-1] * m

    # 遍历列号，每个列号对互相心仪的行号发起配对请求
    for i in range(n):
        # 记录增广路访问过的行号
        vis = [False] * m
        if dfs(i, kth, match, vis):
            smallerCount += 1

    return smallerCount >= n - k + 1


# 算法入口
def getResult():
    low = 1
    high = -sys.maxsize

    for i in range(n):
        for j in range(m):
            high = max(high, matrix[i][j])

    # 二分枚举第K大值
    while low <= high:
        # mid就是被枚举出来的N个数中的第K大值
        mid = (low + high) >> 1

        # 检查mid作为N个数中第K大值时，是否存在N-K+1个<=它的值
        if check(mid):
            high = mid - 1
        else:
            low = mid + 1

    return low


# 算法调用
print(getResult())
