# 输入获取
balls = list(map(int, input().split()))
n = int(input())


def check(index, buckets, limit):
    """
    :param index: 要被装入球的（balls）索引
    :param buckets: 桶数组，buckets[i]记录第i个桶的已经使用的容量
    :param limit: 每个桶的最大容量，即限制
    :return: k个桶（每个桶容量limit）是否可以装下所有balls
    """
    if index == len(balls):
        # 如果balls已经取完，则说明k个limit容量的桶，可以装完所有balls
        return True

    # select是当前要装的球
    selected = balls[index]

    # 遍历桶
    for i in range(len(buckets)):
        # 剪枝优化
        if i > 0 and buckets[i] == buckets[i - 1]:
            continue

        # 如果当前桶装了当前选择的球后不超过容量限制，则可以装入
        if selected + buckets[i] <= limit:
            buckets[i] += selected
            # 递归装下一个球
            if check(index + 1, buckets, limit):
                return True
            # 如果这种策略无法装完所有球，则回溯
            buckets[i] -= selected

    return False


# 算法入口
def getResult():
    # 这里对balls降序，有利于降低后面回溯操作的复杂度
    balls.sort(reverse=True)

    # 分范围：即每个桶的容量最小，最大值
    low = balls[0]  # 桶至少要有max(balls)的容量
    high = sum(balls)  # 当只有一个桶时，此时该桶容量要装下所有balls

    # 记录题解
    ans = high

    # 二分找中间值作为桶容量
    while low <= high:
        mid = (low + high) >> 1

        if check(0, [0] * n, mid):
            # 如果k个mid容量的桶，可以装完所有balls，那么mid容量就是一个可能解，但不一定是最优解，我们应该尝试更小的桶容量
            ans = mid
            high = mid - 1
        else:
            # 如果k个mid容量的桶，无法装完所有balls，那么说明桶容量取小了，我们应该尝试更大的桶容量
            low = mid + 1

    return ans


# 算法调用
print(getResult())
