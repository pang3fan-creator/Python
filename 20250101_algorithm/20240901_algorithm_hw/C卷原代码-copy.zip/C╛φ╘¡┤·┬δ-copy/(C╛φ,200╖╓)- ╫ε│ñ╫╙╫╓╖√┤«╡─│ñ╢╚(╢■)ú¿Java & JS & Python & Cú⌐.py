# 输入获取
s = input()


# 算法入口
def getResult():
    status = 0b000

    # dic[i] 用于记录 状态i 出现的过的所有位置
    dic = [[] for _ in range(8)]
    dic[0].append(-1)

    maxLen = 0

    for i in range(2 * len(s)):
        # 第二轮时，i>=s.length，此时i需要对s.length求余，避免后面越界
        c = s[i % len(s)]

        if c == 'l':
            status ^= 0b100
        elif c == 'o':
            status ^= 0b010
        elif c == 'x':
            status ^= 0b001

        if i < len(s):
            # 第一轮时，i ∈ [0, s.length()), 左闭右开
            # 记录该状态出现过的所有位置
            dic[status].append(i)

        while len(dic[status]) > 0:
            # status状态最早出现的位置
            earliest = dic[status][0]

            # i 是当前位置，和 earliest 位置的状态相同
            if i - earliest > len(s):
                # 如果 [earliest, i] 范围子串长度超过s串长度，则说明earliest左越界，应该尝试更大一点的earliest
                dic[status].pop(0)
            else:
                # 如果 [earliest, i] 范围子串长度未超过s串长度，则该范围子串就是一个符合要求的子串，记录此时子串长度
                maxLen = max(maxLen, i - earliest)
                break

    return maxLen


# 算法调用
print(getResult())
