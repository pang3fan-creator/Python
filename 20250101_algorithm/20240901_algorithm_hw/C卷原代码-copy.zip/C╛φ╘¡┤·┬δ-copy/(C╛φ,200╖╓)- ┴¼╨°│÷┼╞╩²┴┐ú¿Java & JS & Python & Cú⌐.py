# 输入获取
nums = input().split()
colors = input().split()


def dfs(cards, used, last, count, ans):
    ans[0] = max(ans[0], count)

    for i in range(len(cards)):
        if used[i]:
            continue

        cur = cards[i]
        if last and last.num != cur.num and last.color != cur.color:
            continue

        used[i] = True
        dfs(cards, used, cur, count + 1, ans)
        used[i] = False


class Card:
    def __init__(self, num, color):
        self.num = num
        self.color = color


# 算法入口
def getResult():
    n = len(nums)

    cards = [Card(nums[i], colors[i]) for i in range(n)]

    ans = [0]
    used = [False] * n

    dfs(cards, used, None, 0, ans)

    return ans[0]


# 算法调用
print(getResult())
