# 输入获取
s = input()


# 算法入口
def getResult(s):
    count = 0

    stack = []
    for c in s:
        if c != '(' and c != ')':
            continue

        if len(stack) > 0 and c == ')':
            if stack[-1] == '(':
                stack.pop()
                count += 1
                continue
            return -1

        stack.append(c)

    if len(stack) > 0:
        return -1

    return count


# 算法调用
print(getResult(s))
