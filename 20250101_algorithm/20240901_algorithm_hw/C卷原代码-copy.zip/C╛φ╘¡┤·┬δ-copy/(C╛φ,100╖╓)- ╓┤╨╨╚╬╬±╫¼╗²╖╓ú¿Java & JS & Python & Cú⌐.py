import queue

# 输入获取
n = int(input())
t = int(input())
wos = [list(map(int, input().split())) for i in range(n)]


# 算法入口
def getResult():
    # 按照任务截止时间升序
    wos.sort(key=lambda x: x[0])

    # pq用于按照积分对任务进行优先级排序，积分越小，优先级越高，目的是为了每次替换掉最少积分的工单
    pq = queue.PriorityQueue()

    # ans 记录拿到的积分
    ans = 0
    # curTime 记录当前时间
    curTime = 0

    # 遍历任务
    for wo in wos:
        # 任务截止时间, 任务积分
        endTime, score = wo

        if curTime < endTime:
            # 如果 curTime < 当前任务的截止时间，则curTime时刻可以指向当前任务
            pq.put(score)
            ans += score
            curTime += 1
        else:
            # 如果 curTime >= 当前任务的截止时间，则当前任务只能在curTime时刻之前找一个时间点执行

            # pq中记录的就是curTime之前时刻执行的任务
            if pq.qsize() == 0:
                continue

            # 此时取出pq记录的可执行的任务中最小积分的那个
            min_score = pq.queue[0]

            # 如果当前任务的积分 > 前面时间内可执行的任务中最小积分
            if score > min_score:
                # 则我们应该将执行pq中最小积分任务的时间，用于执行当前任务，因为这样可以获得更大积分
                pq.get()
                pq.put(score)
                ans += score - min_score

    # 由于时间限制为t单位，而每个任务花费1单位时间，因此最多完成t个任务，对于多出任务应该去除，且优先去除积分少的
    while pq.qsize() > t:
        ans -= pq.get()

    return ans


# 算法调用
print(getResult())