# 双向节点
class Node:
    def __init__(self, val):
        self.val = val
        self.next = None
        self.prev = None


# 循环链表
class CycleLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None
        self.size = 0

    def append(self, val):
        node = Node(val)

        if self.size > 0:
            self.tail.next = node
            node.prev = self.tail
            self.tail = node
        else:
            self.head = node
            self.tail = node

        self.head.prev = self.tail
        self.tail.next = self.head
        self.size += 1

    def remove(self, cur):
        pre = cur.prev
        nxt = cur.next

        pre.next = nxt
        nxt.prev = pre

        cur.next = cur.prev = None

        if self.head == cur:
            self.head = nxt

        if self.tail == cur:
            self.tail = pre

        self.size -= 1

        return nxt

    def __str__(self):
        arr = []
        cur = self.head

        for i in range(self.size):
            arr.append(str(cur.val))
            cur = cur.next

        return ",".join(arr)


# 算法入口
def getResult():
    if m <= 1 or m >= 100:
        return "ERROR!"

    cycList = CycleLinkedList()
    for i in range(1, 101):
        cycList.append(i)

    idx = 1
    cur = cycList.head

    while cycList.size >= m:
        if idx == m:
            idx = 1
            cur = cycList.remove(cur)
        else:
            idx += 1
            cur = cur.next

    return str(cycList)


if __name__ == '__main__':
    while True:
        try:
            # 输入获取
            m = int(input())

            # 算法调用
            print(getResult())
        except:
            break
