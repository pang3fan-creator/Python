class Student:
    def __init__(self, name, rank):
        self.name = name
        self.rank = rank


# 学生人数, 科目数量
n, m = map(int, input().split())

# key是科目名称，val是科目出现顺序的序号
subject_rankIdx = {}

# 输入的m个科目
subjects = input().split()

for i in range(m):
    subject_rankIdx[subjects[i]] = i

students = []
for i in range(n):
    tmp = input().split()

    # 学生姓名
    name = tmp[0]
    # 学生给定科目的分数（m个）
    scores = list(map(int, tmp[1:]))

    # 排名要素，0~m-1索引上的是给定科目成绩，m索引上的是总分
    rank = []
    rank.extend(scores)
    rank.append(sum(scores))

    students.append(Student(name, rank))

# 用作排名的科目名称
subject = input()

#  用作排名的科目名称的排名要素序号, 如果用作排名的科目名称不存在，则按总分排名，对应序号是m
rankIdx = subject_rankIdx.get(subject, m)

# 按照排名要素排名，如果排名要素值相同，则按照学生姓名字典序排序
students.sort(key=lambda x: (-x.rank[rankIdx], x.name))

print(" ".join(map(lambda x: x.name, students)))
