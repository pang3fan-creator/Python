# 输入获取
arr1 = list(map(int, input().split()))[1:]
arr2 = list(map(int, input().split()))[1:]
k = int(input())


# 算法入口
def getResult():
    pairs = []
    for v1 in arr1:
        for v2 in arr2:
            pairs.append(v1 + v2)

    pairs.sort()

    sumV = 0
    for i in range(k):
        sumV += pairs[i]

    return sumV


# 算法调用
print(getResult())