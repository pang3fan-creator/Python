# 输入获取
nums = list(map(int, input().split(",")))
target = int(input())


# 算法入口
def binarySearch():
    # 参照Java的Arrays.binarySearch实现
    low = 0
    high = len(nums) - 1

    while low <= high:
        mid = (low + high) >> 1
        midVal = nums[mid]

        if midVal > target:
            high = mid - 1
        elif midVal < target:
            low = mid + 1
        else:
            return mid  # 如果nums中存在target，则返回target的位置

    return -low - 1  # 如果nums中不存在target，则low就是target在nums中的有序插入位置，为了避免冲突，这里设计为负数返回


# 算法调用
idx = binarySearch()

if idx < 0:
    idx = -idx - 1

# 队列位置（从1开始），因此索引+1
print(idx + 1)
