import decimal  # 超大数运算内置库
from decimal import Decimal

decimal.setcontext(decimal.Context(prec=2500))  # 设置超大数精度

m = int(input())
factor = []


# 阶乘
def initFactor(n):
    factor.append(Decimal(1))

    for i in range(1, n + 1):
        factor.append(Decimal(i) * factor[-1])


# 求解不重复的全排列数
def getPermutationCount(oneCount, twoCount):
    if oneCount == 0 or twoCount == 0:
        # 即 1 1 1 1 1 或 2 2 2 这种情况，此时只有一种排列
        return 1
    else:
        # 排列数去重，比如 1 1 1 2 2 的不重复排列数为 5! / 3! / 2! = 10
        return factor[oneCount + twoCount] / factor[oneCount] / factor[twoCount]


def getResult():
    initFactor(m - 7)

    oneCount = m - 7
    twoCount = 0

    # 记录B赢的情况数
    ans = Decimal(0)

    while oneCount >= 0:
        # 叫的次数为奇数时，才能B赢
        if (oneCount + twoCount) % 2 != 0:
            ans += getPermutationCount(oneCount, twoCount)

        # 合并两个1为一个2
        oneCount -= 2
        twoCount += 1

    return ans


print("{:.0f}".format(getResult()))
