# 输入获取
desk = list(input())


# 算法入口
def getResult():
    ans = 0

    i = 0
    while i < len(desk):
        if desk[i] == '0':
            isLeftEmpty = i == 0 or desk[i - 1] == '0'
            isRightEmpty = i == len(desk) - 1 or desk[i + 1] == '0'

            if isLeftEmpty and isRightEmpty:
                ans += 1
                desk[i] = '1'
                i += 1
        i += 1

    return ans


# 算法调用
print(getResult())
