# 输入获取
k = int(input())
n = int(input())
words = [input() for _ in range(n)]


# 算法入口
def getResult():
    chain = [words.pop(k)]

    prefix = {}
    for word in words:
        w = word[0]
        if prefix.get(w) is None:
            prefix[w] = []
        prefix[w].append(word)

    for w in prefix.keys():
        prefix[w].sort(key=lambda x: (-len(x), [ord(i) for i in x]))

    while True:
        tail = chain[-1][-1]

        if prefix.get(tail):
            chain.append(prefix[tail].pop(0))
        else:
            break

    return "".join(chain)


# 调用算法
print(getResult())
