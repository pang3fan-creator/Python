# 输入获取
n = int(input())
arr = input().split()

# 全局变量
path = []
used = [False] * n
cache = set()


# 全排列求解
def dfs():
    if len(path) == n:
        cache.add("".join(path))
        return

    for i in range(n):
        if used[i]:
            continue

        # 树层去重
        if i > 0 and arr[i] == arr[i - 1] and not used[i - 1]:
            continue

        path.append(arr[i])
        used[i] = True
        dfs()
        used[i] = False
        path.pop()


# 算法入口
def getResult():
    # 排序是为了让相同元素相邻，方便后面树层去重
    arr.sort()
    dfs()

    # 输出石碑文字的组合（按照升序排列）
    for v in sorted(list(cache)):
        print(v)


# 算法调用
getResult()
