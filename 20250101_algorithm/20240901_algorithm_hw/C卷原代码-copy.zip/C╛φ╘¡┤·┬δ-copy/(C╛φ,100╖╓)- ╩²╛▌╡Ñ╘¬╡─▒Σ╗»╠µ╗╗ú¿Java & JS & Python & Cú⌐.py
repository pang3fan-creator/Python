import re

regexp = re.compile(r"(<.*?>)")

# 输入获取
cells = input().split(",")


def changeCell(index):
    # 通过正则匹配出单元格内容中"引用字符串"
    matchers = regexp.findall(cells[index])

    # reference记录引用字符串
    for reference in matchers:
        # 引用单元格编号只能是A~Z的字母，即引用引用字符串长度只能是3，比如"<A>"
        if len(reference) != 3:
            return False

        # 引用单元格的编号
        reference_cellNum = reference[1]
        # 当前单元格的编号
        self_cellNum = chr(65 + index)

        # 引用单元格编号只能是A~Z的字母，且不能自引用
        if reference_cellNum < 'A' or reference_cellNum > 'Z' or reference_cellNum == self_cellNum:
            return False

        # 引用单元格的数组索引， 'A' -> 0  ... 'Z' -> 25
        reference_index = ord(reference_cellNum) - 65

        # 引用单元格编号不存在
        if reference_index >= len(cells):
            return False

        if not changeCell(reference_index):
            return False

        # 将单元格内容中的引用部分，替换为被引用的单元格的内容
        cells[index] = cells[index].replace(reference, cells[reference_index])

    return True


# 算法入口
def getResult():
    for i in range(len(cells)):
        # 替换单元格中的引用，替换失败，则返回-1
        if not changeCell(i):
            return "-1"

    # 替换成功，则记录单元格内容
    return ",".join(cells)


# 算法调用
print(getResult())
