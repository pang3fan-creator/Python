import re

# 输入获取
s = input()


# 算法入口
def getResult(s):
    # 去除非括号字符
    s = re.sub(r"[^\(\)\[\]\{\}]", "", s)

    map = {
        ")": "(",
        "]": "[",
        "}": "{"
    }

    stack = []

    for i in range(len(s)):
        c = s[i]

        if len(stack) > 0 and map.get(c) is not None:
            if stack[-1] == map[c]:
                stack.pop()
                continue
            else:
                return False

        stack.append(c)

    return len(stack) == 0


# 算法调用
print(str(getResult(s)).lower())