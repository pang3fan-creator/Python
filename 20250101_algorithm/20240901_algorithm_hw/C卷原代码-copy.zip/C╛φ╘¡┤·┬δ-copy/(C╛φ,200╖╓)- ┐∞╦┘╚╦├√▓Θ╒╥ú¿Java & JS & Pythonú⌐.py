# 输入获取
names = input().split(",")
abbr = input()


# 通过递归实现人名各部分和缩写的匹配
def recursive(parts, parts_index, abbr_index):
    """
    :param parts: 人名组成
    :param parts_index: 人名被匹配的组成部分的索引位置
    :param abbr_index: 缩写被匹配的字符的索引位置
    :return: 当前人名name是否匹配对应缩写abbr
    """
    if abbr_index >= len(abbr):
        # 如果缩写被匹配完，且人名组成也匹配到最后一个，则说明当前人名可以匹配对应缩写
        return parts_index >= len(parts)

    # 如果缩写尚未匹配完，但是人名组成已经匹配完，则说明当前人名无法匹配对应缩写
    if parts_index >= len(parts):
        return False

    part_name = parts[parts_index]

    for j in range(len(part_name)):
        # 如果当前人名组成部分part_name的第 j 个字符 可以 匹配 缩写abbr的第 abbr_index个字符
        if abbr_index < len(abbr) and part_name[j] == abbr[abbr_index]:
            # 为了保证part_name匹配不回退，此时我们将缩写abbr的第abbr_index+1个字符的匹配权优先交给人名的parts_index + 1部分
            abbr_index += 1
            if recursive(parts, parts_index + 1, abbr_index):
                return True
        else:
            return False

    return False


# 算法入口
def getResult():
    ans = []

    for name in names:
        parts = name.split()

        if len(parts) > len(abbr):
            continue

        if recursive(parts, 0, 0):
            ans.append(name)

    print(",".join(ans))


# 算法调用
getResult()
