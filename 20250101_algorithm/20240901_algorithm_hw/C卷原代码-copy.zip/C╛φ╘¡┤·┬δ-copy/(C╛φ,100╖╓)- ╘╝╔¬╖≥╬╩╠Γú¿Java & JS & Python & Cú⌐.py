from collections import deque

# 输入获取
input_arr = deque(list(map(int, input().split(","))))
length = int(input())
m = int(input())


# 算法入口
def getResult():
    global input_arr
    global length
    global m

    output_arr = []

    i = 1
    while length > 0:
        out = input_arr.popleft()
        if i == m:
            output_arr.append(out)
            m = out
            i = 1
            length -= 1
        else:
            input_arr.append(out)
            i += 1

    return ",".join(map(str, output_arr))


# 算法调用
print(getResult())
