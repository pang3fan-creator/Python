import math

# 输入获取
bricks = list(map(int, input().split()))


def check(energy, limit):
    """
    :param energy: 每小时可以使用的能量块数量（搬一块砖消耗一块能量）
    :param limit: 限制几小时内干完
    :return: 是否可以在limit小时内搬完所有bricks
    """
    cost = 0  # 已花费的小时数

    for brick in bricks:
        cost += math.ceil(brick / energy)

        # 如果搬砖过程中发现，花费时间已经超过限制，则直接返回false
        if cost > limit:
            return False

    return True


# 算法入口
def getResult():
    # 机器人每小时只能在一个仓库干活，因此给定8小时，最多只能搬完8个仓库，如果仓库数量超过8，那么肯定干不完
    if len(bricks) > 8:
        return -1

    # 每小时最多需要的能量块
    maxEnergy = max(bricks)

    # 如果有8个仓库，那么只能1个小时干1个仓库，且机器人每小时需要能量至少是max(bricks)，这样才能保证1个小时内把最多砖块的那个仓库搬完
    if len(bricks) == 8:
        return maxEnergy

    # 如果仓库数少于8个，那么此时每小时能量max(bricks)必然能在8小时内搬完所有仓库，但不是最优解
    ans = maxEnergy

    # 每小时最少需要的能量块
    minEnergy = 1

    # 二分法
    while minEnergy <= maxEnergy:
        # 取中间值
        mid = (minEnergy + maxEnergy) >> 1

        if check(mid, 8):
            # 如果每小时充mid格能量，就能在8小时内，搬完所有砖头，则mid就是一个可能解
            ans = mid
            # 但mid不一定是最优解，因此继续尝试更小的能量块
            maxEnergy = mid - 1
        else:
            # 如果每小时充mid能量块，无法在8小时能完成工作，则说明每天能量块充少了，下次应该尝试充更多能量块
            minEnergy = mid + 1

    return ans


# 算法调用
print(getResult())
