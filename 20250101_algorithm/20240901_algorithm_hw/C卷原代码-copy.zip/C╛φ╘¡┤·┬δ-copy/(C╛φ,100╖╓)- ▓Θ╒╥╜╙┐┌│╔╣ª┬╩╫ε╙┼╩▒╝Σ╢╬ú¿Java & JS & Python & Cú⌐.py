# 输入获取
minAverageLost = int(input())
nums = list(map(int, input().split()))


# 算法入口
def getResult():
    n = len(nums)

    preSum = [0] * (n + 1)
    for i in range(1, n + 1):
        preSum[i] = preSum[i - 1] + nums[i - 1]

    ans = []
    maxLen = 0
    for i in range(n):
        for j in range(i + 1, n + 1):
            # sumV 是 区间 [i, j-1] 的和
            sumV = preSum[j] - preSum[i]
            length = j - i
            lost = length * minAverageLost

            if sumV <= lost:
                if length > maxLen:
                    ans = [[i, j - 1]]
                    maxLen = length
                elif length == maxLen:
                    ans.append([i, j - 1])

    ans.sort(key=lambda x: x[0])

    if len(ans) == 0:
        return "NULL"
    else:
        return " ".join(map(lambda x: "-".join(map(str, x)), ans))


# 算法调用
print(getResult())
