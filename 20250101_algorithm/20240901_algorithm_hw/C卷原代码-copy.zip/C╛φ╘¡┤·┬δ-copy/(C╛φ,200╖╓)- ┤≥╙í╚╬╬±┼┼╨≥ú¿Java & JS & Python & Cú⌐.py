# 输入获取
priorities = list(map(int, input().split(",")))


# 算法入口
def getResult():
    link = [[p, i] for i, p in enumerate(priorities)]

    n = len(priorities)

    priorities.sort()
    maxI = n - 1

    ans = [0] * n
    printIdx = 0
    while len(link) > 0:
        p, i = link.pop(0)

        if p == priorities[maxI]:
            ans[i] = printIdx
            printIdx += 1
            maxI -= 1
        else:
            link.append([p, i])

    return ",".join(map(str, ans))


# 算法调用
print(getResult())
