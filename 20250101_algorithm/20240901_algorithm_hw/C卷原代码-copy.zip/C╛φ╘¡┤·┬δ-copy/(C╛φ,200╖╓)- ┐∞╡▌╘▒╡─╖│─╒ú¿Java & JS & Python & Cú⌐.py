import sys

# 输入获取
n, m = map(int, input().split())

# floyd算法需要基于dist和path矩阵求解
# dist[i][j] 用于记录点 i->j 的最短距离，初始时等价于邻接矩阵
dist = [[sys.maxsize] * (n + 1) for _ in range(n + 1)]
# path[i][j] 用于记录点 i->j 最短距离情况下需要经过的中转点，初始时默认任意两点间无中转点，即默认path[i][j] = -1
path = [[-1] * (n + 1) for _ in range(n + 1)]

# 由于本题的客户id不是顺序的，因此这里需要将客户id离散化处理
dic = {}

for i in range(1, n + 1):
    idx, dis = map(int, input().split())

    # 离散化处理
    dic[idx] = i

    # 投递站到客户之间的距离distance
    dist[0][i] = dis
    dist[i][0] = dis

for i in range(1, m + 1):
    idx1, idx2, dis = map(int, input().split())

    i1 = dic[idx1]
    i2 = dic[idx2]

    # 客户与客户之间的距离信息
    dist[i1][i2] = dis
    dist[i2][i1] = dis

# ans记录经过所有点后回到出发点的最短距离
ans = sys.maxsize


# floyd算法求解图中任意两点之间的最短路径
def floyd():
    for k in range(n + 1):
        for i in range(n + 1):
            for j in range(n + 1):
                # newDist是经过k后，i->j的距离
                newDist = dist[i][k] + dist[k][j]
                # 如果newDist是i->j的更短路径
                if newDist < dist[i][j]:
                    # 则更新i->j的最短距离
                    dist[i][j] = newDist
                    # 且此更短距离需要经过k, path[i][j]即记录 i->j 最短距离下需要经过点 k
                    path[i][j] = k


def dfs(pre, sumDis, used, level):
    """
    找一条经过所有点的最短路径，我们可以求解所有点形成的全排列，每一个全排列都对应一条经过所有点的路径，只是经过点的先后顺序不同 //
    求某个全排列过程中，可以通过dist数组，累计上一个点i到下一个点j的最短路径dist[i][j]
    :param pre: 上一个点, 初始为0，表示从披萨店出发
    :param sumDis: 当前全排列路径累计的路径权重
    :param used: 全排列used数组，用于标记哪些点已使用过
    :param level: 用于记录排列的长度
    """
    global ans

    if level == n:
        # 此时pre是最后一个客户所在点，送完最后一个客户后，司机需要回到披萨店，因此最终累计路径权重为 sum + dist[pre][0]
        # 我们保留最小权重路径
        ans = min(ans, sumDis + dist[pre][0])
        return

    for i in range(1, n + 1):
        if used[i]:
            continue

        used[i] = True
        dfs(i, sumDis + dist[pre][i], used, level + 1)
        used[i] = False


# 算法入口
def main():
    # floyd算法调用
    floyd()

    # 全排列模拟经过所有点的路径
    dfs(0, 0, [False] * (n + 1), 0)

    print(ans)


# 算法调用
main()
