# 输入获取
n, m = map(int, input().split())
matrix = [list(map(int, input().split())) for _ in range(n)]

offsets = ((-1, 0), (1, 0), (0, -1), (0, 1))


def bfs(i, j):
    count = 1
    matrix[i][j] = 0

    queue = [[i, j]]

    while len(queue) > 0:
        x, y = queue.pop(0)

        for offsetX, offsetY in offsets:
            newX = x + offsetX
            newY = y + offsetY

            if n > newX >= 0 and m > newY >= 0 and matrix[newX][newY] == 1:
                count += 1
                matrix[newX][newY] = 0
                queue.append([newX, newY])

    return count


# 算法入口
def getResult():
    ans = 0

    for i in range(n):
        for j in range(m):
            if matrix[i][j] == 1:
                ans = max(ans, bfs(i, j))

    return ans


# 算法调用
print(getResult())
