# 输入获取
relations = eval(input())  # 二维列表，元素列表含义是[师傅排名，徒弟排名]


def getHighC(fa, f, src, highC):
    """
    :param fa: fa用于统计每个师傅名下的直接徒弟的排名，fa对象的属性是师傅排名，属性值是一个数组，里面元素是直接徒弟的排名
    :param f: 当前的师傅，初始时为源头祖师
    :param src: 源头祖师
    :param highC: 比源头祖师排名的高的徒弟的排名集合
    :return: 比源头祖师排名的高的徒弟的个数，即highC.size
    """
    # 如果当前师傅是第一名，那么肯定没有徒弟超过它，因此直接返回0
    if f == 1:
        return 0

    # 遍历当前师傅的所有徒弟
    for c in fa[f]:
        # flag标记是否需要统计间接徒弟，默认需要
        flag = True

        # 如果徒弟的排名高于源头祖师（排名越高，值越小），则应该统计到highC集合中
        if c < src:
            # 如果highC集合没有这个徒弟，则统计，并需要统计这个徒弟的徒弟（即间接徒弟）的排名情况
            if c not in highC:
                highC.add(c)
            else:
                flag = False  # 如果highC中已经有了当前的徒弟，则说明当前徒弟已经统计过了，不需要再统计，且当前徒弟的徒弟也不需要再统计了
        elif c == src:
            return 0  # 形成环，需要打断

        if flag:
            # 统计间接徒弟
            getHighC(fa, c, src, highC)

    return len(highC)


# 算法入口
def getResult():
    # fa用于统计每个师傅名下的直接徒弟的排名，fa对象的属性是师傅排名，属性值是一个数组，里面元素是直接徒弟的排名
    fa = {}

    #  输出结果要求依次统计：排名第一的师傅的高于自己的徒弟的个数，排名第二的师傅的高于自己的徒弟的个数，......
    for f, c in relations:
        if fa.get(f) is not None:
            fa[f].append(c)
        else:
            fa[f] = [c]

        if fa.get(c) is None:
            fa[c] = []

    ans = []

    # 输出结果要求依次统计：排名第一的师傅的高于自己的徒弟的个数，排名第二的师傅的高于自己的徒弟的个数，......
    for f in fa:
        ans.append([f, getHighC(fa, f, f, set())])

    # 按照师傅排名升序后，输出高于师傅排名的徒弟的个数
    ans.sort(key=lambda x: x[0])

    return list(map(lambda x: x[1], ans))


# 算法调用
print(getResult())
