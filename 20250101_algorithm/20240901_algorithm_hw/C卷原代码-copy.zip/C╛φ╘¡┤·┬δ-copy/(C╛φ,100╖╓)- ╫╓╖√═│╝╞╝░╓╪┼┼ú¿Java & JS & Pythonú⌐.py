# 输入获取
import functools

s = input()


def cmp(a, b):
    if a[1] != b[1]:
        return b[1] - a[1]

    if (a[0].islower() and b[0].islower()) or (a[0].isupper() and b[0].isupper()):
        return 1 if a[0] > b[0] else -1
    else:
        if a[0].isupper():
            return 1
        else:
            return -1


# 算法入口
def getResult():
    letter = {}

    for c in s:
        letter[c] = letter.get(c, 0) + 1

    letterList = list(letter.items())

    letterList.sort(key=functools.cmp_to_key(cmp))

    return "".join(list(map(lambda x: f"{x[0]}:{x[1]};", letterList)))


# 算法调用
print(getResult())
