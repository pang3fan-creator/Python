# 输入获取
n = int(input())

words = []
for i in range(n):
    words.append(input())

chars = input()


def charStatistic(s):
    cnts = [0] * 128

    for c in s:
        cnts[ord(c)] += 1

    return cnts


# 算法入口
def getResult():
    ans = 0

    # 统计chars字符串中各字符的数量
    cnt_chars = charStatistic(chars)

    for word in words:
        diff = 0

        # 统计word字符串中各字符的数量
        cnt_word = charStatistic(word)

        for j in range(128):
            # 记录word的某字符超过chars的对应字符出现的数量
            diff += max(cnt_word[j] - cnt_chars[j], 0)

        if diff <= cnt_chars[ord('?')]:
            ans += 1
            # print(word)

    return ans


# 算法调用
print(getResult())