# 输入获取
m, n = map(int, input().split())

# 记录前车到达终点的时刻，本题后车不可能比前车更早到达，因此如果后车到达时刻 < 前车到达时刻arrived，则后车也是按照前车arrived时刻达到
arrived = 0

for i in range(m):
    # 当前车的速度
    speed = int(input())
    # 当前车到达终点的时刻
    # * 当前车如果比前车更早到达，则被前车阻碍，按前车到达时间算
    # * 当前车如果比前车更晚到达，则不被前车阻碍，按后车到达时间算
    arrived = max(arrived, n / speed + i)  # n*1.0/speed是行驶花费时间； i是第i辆车的出发时间

# 到达时刻 - 出发时刻 = 路上花费的时间
cost = arrived - (m - 1)

print("{:g}".format(round(cost, 3)))  # 如果有小数位则至多保留3位，:g 用于去除无效小数位
