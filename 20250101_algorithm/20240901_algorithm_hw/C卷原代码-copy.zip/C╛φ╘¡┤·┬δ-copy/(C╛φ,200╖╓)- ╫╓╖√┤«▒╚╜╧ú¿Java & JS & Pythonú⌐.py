# 输入获取
a = input()
b = input()
v = int(input())


# 算法入口
def getResult():
    n = len(a)

    # a,b字符串的各位字符的ascii绝对值差距数组
    preSum = [0] * (n + 1)
    for i in range(1, n + 1):
        preSum[i] = preSum[i - 1] + abs(ord(a[i - 1]) - ord(b[i - 1]))

    # 记录题解
    ans = 0

    for l in range(n):
        for r in range(l + 1, n + 1):
            # 区间 [l+1, r]的和 = preSum[r] - preSum[l]
            if preSum[r] - preSum[l] <= v:
                ans = max(ans, r - l)

    return ans


# 调用算法
print(getResult())
