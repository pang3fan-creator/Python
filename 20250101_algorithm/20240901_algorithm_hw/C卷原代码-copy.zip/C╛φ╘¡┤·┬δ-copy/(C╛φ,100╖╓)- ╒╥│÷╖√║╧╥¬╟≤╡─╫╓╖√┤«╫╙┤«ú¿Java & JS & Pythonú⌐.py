# 输入获取
s1 = input()
s2 = input()


# 算法入口
def getResult():
    set1 = set(s1)
    set2 = set(s2)

    set3 = set1.intersection(set2)

    ans = list(set3)
    ans.sort()

    return "".join(ans)


# 调用算法
print(getResult())
