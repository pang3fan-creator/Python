# 输入获取
n = int(input())
seqs = list(map(int, input().split()))
threshold = int(input())

# 统计各个内存页框号出现的次数
cnts = {}
for num in seqs:
    cnts.setdefault(num, 0)
    cnts[num] += 1

# 过滤出现次数达到阈值的内存页，即热内存页数量
items = list(filter(lambda x: x[1] >= threshold, cnts.items()))

# 打印热内存页数量
print(len(items))

# 如果存在热内存页
if len(items) > 0:
    # 那么优先按照访问频次降序，如果访问频次相同，则再按页框号升序，items中记录元素是[页框号, 访问频次]
    items.sort(key=lambda x: (-x[1], x[0]))

    for num, _ in items:
        print(num)