# 算法入口
def turnDice(directives):
    dice = Dice()

    for directive in directives:
        if directive == "L":
            dice.turnL()
        elif directive == "R":
            dice.turnR()
        elif directive == "F":
            dice.turnF()
        elif directive == "B":
            dice.turnB()
        elif directive == "A":
            dice.turnA()
        elif directive == "C":
            dice.turnC()

    return str(dice)


# 筛子实现类
class Dice:
    def __init__(self):
        self.left = 1
        self.right = 2
        self.front = 3
        self.back = 4
        self.top = 5
        self.bottom = 6

    def turnL(self):
        # 前后不变，上变左，左变下，下变右，右变上
        self.right, self.bottom, self.left, self.top = self.bottom, self.left, self.top, self.right

    def turnR(self):
        # 前后不变，上变右，右变下，下变左，左变上
        self.left, self.bottom, self.right, self.top = self.bottom, self.right, self.top, self.left

    def turnF(self):
        # 左右不变，上变前，前变下，下变后，后变上
        self.front, self.top, self.back, self.bottom = self.top, self.back, self.bottom, self.front

    def turnB(self):
        # 左右不变，前变上，上变后，后变下，下边前
        self.top, self.front, self.bottom, self.back = self.front, self.bottom, self.back, self.top

    def turnA(self):
        # 上下不变， 前变右，右变后，后变左，左变前
        self.right, self.front, self.left, self.back = self.front, self.left, self.back, self.right

    def turnC(self):
        # 上下不变， 右变前，前变左，左变后，后变右
        self.front, self.right, self.back, self.left = self.right, self.back, self.left, self.front

    def __str__(self):
        return f"{self.left}{self.right}{self.front}{self.back}{self.top}{self.bottom}"


# 输入获取
directives = input().split()

# 算法调用
print(turnDice(directives))
