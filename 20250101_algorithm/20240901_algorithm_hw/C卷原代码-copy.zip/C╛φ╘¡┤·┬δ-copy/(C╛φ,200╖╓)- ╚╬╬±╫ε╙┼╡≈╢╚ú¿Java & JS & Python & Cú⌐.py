# 输入获取
tasks = list(map(int, input().split(",")))
n = int(input())


# 算法入口
def getResult():
    cnts = {}

    for task in tasks:
        cnts[task] = cnts.get(task, 0) + 1

    # k表示: 最多任务的数量
    # 比如2, 2, 2, 3， 其中任务2数量最多，有3个，则k = 3
    k = max(cnts.values())

    # p表示: 数量为k的任务个数
    # 比如2, 2, 2, 3, 3, 3, 4， 其中数量为3的任务有2个，分别是任务2，任务3，则p = 2
    p = 0
    for task in cnts:
        if cnts[task] == k:
            p += 1

    return max((k - 1) * (n + 1) + p, len(tasks))


# 算法调用
print(getResult())
