# 输入获取
heights = list(map(int, input().split(",")))
strength = int(input())


def climb(idxs, direction):
    # 找到第一个地面位置
    j = 0
    while j < len(heights) and heights[j] != 0:
        j += 1

    # 上山体力消耗
    # upCost = 0
    # 下山体力消耗
    # downCost = 0

    # 攀登体力总消耗（包括上山，下山）
    cost = 0

    for i in range(j + 1, len(heights)):
        # 如果遇到了新的地面，则从新的地面位置重新计算攀登消耗的体力
        if heights[i] == 0:
            cost = 0
            # upCost = 0
            # downCost = 0
            continue

        # diff记录高度差
        diff = heights[i] - heights[i - 1]

        if diff > 0:
            # 如果过程是上坡
            cost += diff * 3
            # upCost += diff * 2  # 则上山时，体力消耗 = 高度差 * 2
            # downCost += diff  # 相反的下山时，体力消耗 = 高度差 * 1

            # 由于 height[i] > heights[i-1]，因此如果 height[i] > heights[i+1] 的话，位置 i 就是山顶
            if i + 1 >= len(heights) or heights[i] > heights[i + 1]:
                # 计算攀登此山顶的上山下山消耗的体力和
                if cost < strength:
                    # if upCost + downCost <= strength:
                    # 如果不超过自身体力，则可以攀登
                    if direction:
                        idxs.add(i)
                    else:
                        idxs.add(len(heights) - i - 1)  # 需要注意，逆序heights数组后，我们对于的山峰位置需要反转

        elif diff < 0:
            # 如果过程是下坡
            cost -= diff * 3
            # upCost -= diff  # 则上山时，体力消耗 = 高度差 * 1
            # downCost -= diff * 2  # 相反的下山时，体力消耗 = 高度差 * 2
            # heights[i] < heights[i-1]，因此位置i不可能是山顶


# 算法入口
def getResult():
    # 记录可攀登的山峰索引
    idxs = set()

    # 正向攀登
    climb(idxs, True)

    # 逆序攀登
    heights.reverse()
    climb(idxs, False)

    return len(idxs)


# 算法调用
print(getResult())
