import math

# 输入获取
# n 表示需要在螺旋矩阵中填入 1 ~ n 数字
# m 表示螺旋矩阵行数
n, m = map(int, input().split())


# 算法入口
def getResult():
    # k是螺旋矩阵列数
    k = int(math.ceil(n / m))

    # 螺旋矩阵
    matrix = [['*'] * k for _ in range(m)]  # 未填值位置默认初始化为*

    # 当前要填入的值
    step = 1

    # 当前要填入的值的位置
    x = 0
    y = 0

    # 如果填入的值 > n，则停止填值，否则继续填
    while step <= n:
        # 正序填入第x行，即：行号不变，列号增加，注意：添值过程不能发生覆盖，也不能填入超过n的值
        while y < k and matrix[x][y] == '*' and step <= n:
            matrix[x][y] = str(step)
            step += 1
            y += 1

        # 正序填完第x行后，y处于末尾越界位置，因此y需要退一步
        y -= 1
        # 正序填完第x行来到第x行的末尾，即第y列，按照螺旋矩阵顺序，应该从第x+1行开始正序填值第y列
        x += 1

        # 正序填入第y列，即：列号不变，行号增加，注意：添值过程不能发生覆盖，也不能填入超过n的值
        while x < m and matrix[x][y] == '*' and step <= n:
            matrix[x][y] = str(step)
            step += 1
            x += 1

        x -= 1
        y -= 1

        # 倒序填入第x行，即：行号不变，列号减少，注意：添值过程不能发生覆盖，也不能填入超过n的值
        while y >= 0 and matrix[x][y] == '*' and step <= n:
            matrix[x][y] = str(step)
            step += 1
            y -= 1

        y += 1
        x -= 1

        # 倒序填入第y列，即：列号不变，行号减少，注意：添值过程不能发生覆盖，也不能填入超过n的值
        while x >= 0 and matrix[x][y] == '*' and step <= n:
            matrix[x][y] = str(step)
            step += 1
            x -= 1

        x += 1
        y += 1

    # 打印螺旋矩阵字符串
    for i in range(m):
        print(" ".join(matrix[i]))


# 算法调用
getResult()
