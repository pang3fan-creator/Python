# 输入获取
sumV, n = map(int, input().split())


# 算法入口
def getResult():
    mid = sumV // n

    if n % 2 == 0:
        half = n // 2
        left = mid - half + 1
        right = mid + half
    else:
        half = (n - 1) // 2
        left = mid - half
        right = mid + half

    arr = [i for i in range(left, right + 1)]
    total = sum(arr)

    if total != sumV:
        return "-1"
    else:
        return " ".join(map(str, arr))


# 算法调用
print(getResult())
