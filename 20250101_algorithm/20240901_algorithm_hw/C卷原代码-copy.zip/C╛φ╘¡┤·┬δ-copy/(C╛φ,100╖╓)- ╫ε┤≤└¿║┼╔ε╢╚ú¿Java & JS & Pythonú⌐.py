# 输入获取
s = input()


# 算法入口
def getResult():
    map = {
        ")": "(",
        "]": "[",
        "}": "{"
    }

    stack = []

    maxDepth = 0
    for i in range(len(s)):
        c = s[i]

        if len(stack) > 0 and map.get(c) is not None and map[c] == stack[-1]:
            stack.pop()
        else:
            stack.append(c)
            maxDepth = max(maxDepth, len(stack))

    if len(stack) > 0:
        return 0

    return maxDepth


# 算法调用
print(getResult())
