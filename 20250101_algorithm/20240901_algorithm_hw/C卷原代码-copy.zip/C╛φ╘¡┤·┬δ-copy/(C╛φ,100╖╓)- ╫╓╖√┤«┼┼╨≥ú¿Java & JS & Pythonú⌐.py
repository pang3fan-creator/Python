# 输入获取
arr = input().split()


# 算法入口
def getResult():
    arr.sort(key=lambda x: x.lower())

    stack = [arr[0]]

    for i in range(1, len(arr)):
        s = arr[i]
        top = stack[-1].lower()
        add = s.lower()
        if top == add:
            continue
        stack.append(s)

    return " ".join(stack)


# 算法调用
print(getResult())