s = input().replace(",", "").replace("111", "x").replace("11", "x").replace("1", "x")

ans = 0
for c in s:
    if c == 'x':
        ans += 1

print(ans)
