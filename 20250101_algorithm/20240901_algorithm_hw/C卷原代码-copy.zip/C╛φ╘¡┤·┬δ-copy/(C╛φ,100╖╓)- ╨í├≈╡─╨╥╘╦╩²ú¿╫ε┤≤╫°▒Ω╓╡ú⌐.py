def getResult():
    n = int(input())

    # 异常情况下输出：12345
    if n < 1 or n > 100:
        print("12345")
        return

    m = int(input())

    # 异常情况下输出：12345
    if m < -100 or m > 100:
        print("12345")
        return

    pos = 0
    maxPos = 0

    nums = list(map(int, input().split()))

    for num in nums:
        # 异常情况下输出：12345
        if num < -100 or num > 100:
            print("12345")
            return

        pos += num

        # 如果某个指令正好和幸运数相等，则小明行进步数+1
        # 注意，如果幸运数字为0，且存在指令为0，那么此时我理解小明应该继续保持不动
        if num == m:
            if num > 0:
                pos += 1
            elif num < 0:
                pos -= 1

        # 比较本次移动后的坐标位置和最大坐标位置
        maxPos = max(maxPos, pos)

    print(maxPos)


getResult()
