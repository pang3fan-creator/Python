import re
import sys


# IP地址转整型
def ip2dec(ipStr):
    res = 0

    blocks = ipStr.split(".")
    for block in blocks:
        res = int(block) | (res << 8)

    return res


class Range:
    def __init__(self, city, startIpStr, endIpStr):
        self.city = city
        # 将IP地址转为整型
        self.startIp = ip2dec(startIpStr)
        self.endIp = ip2dec(endIpStr)
        self.ipLen = self.endIp - self.startIp + 1


# 输入获取
cities = input().split(";")  # 城市IP列表
queryIps = input().split(",")  # 带查询的IP列表

# 核心代码
ranges = []

# 提取各个城市IP列表信息
for s in cities:
    # * 用于函数参数自动解构
    ranges.append(Range(*(re.split(r"[=,]", s))))

ans = []

# 遍历待查询的IP地址
for ip in queryIps:
    ipDec = ip2dec(ip)

    # 记录该目标IP地址的最佳匹配城市
    best_city = ""
    # 记录最佳匹配城市IP段的长度
    minLen = sys.maxsize

    # 将带查询IP与城市IP段列表逐一匹配
    for ran in ranges:
        # 如果带查询的IP地址 在某城市的IP段范围内，且该城市的IP段长度更小，则该城市为待查询IP的最佳匹配城市
        if ran.endIp >= ipDec >= ran.startIp and minLen > ran.ipLen:
            best_city = ran.city
            minLen = ran.ipLen

    ans.append(best_city)

print(",".join(ans))
