# 输入获取
msg = input()
n = int(input())
tags = [int(input()) for i in range(n)]


# 算法入口
def getResul(msg, tags):
    tagDict = {}

    # 这里只遍历到len(msg) - 3的目的是确保tag，len的截取不会越界
    i = 0
    while i < len(msg) - 3:
        tag = int(msg[i:i + 2], 16)
        long = int(msg[i + 2:i + 4], 16)
        valueOffset = (i + 5) // 2

        # 本TLV格式报文段结束位置i
        i += 3 + long * 2

        # 如果结束位置i越界，则当前TLV报文段是一个不完整的，需要丢弃
        if i >= len(msg):
            break

        # 题目已经保证tag不会重复
        tagDict[tag] = [long, valueOffset]

        i += 1

    for tag in tags:
        if tagDict.get(tag) is None:
            print("0 0")
        else:
            print(" ".join(map(str, tagDict[tag])))


# 算法调用
getResul(msg, tags)
