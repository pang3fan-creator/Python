import math

# 输入获取
nums = list(map(int, input().split()))


# 算法入口
def getResult():
    # num是反馈，cnts[num]是给出相同反馈的（小朋友）数量
    cnts = {}

    for num in nums:
        cnts[num] = cnts.get(num, 0) + 1

    # ans 记录题解
    ans = 0
    for key in cnts.keys():
        # key是反馈，假设某小朋友反馈有key个人和自己一个小区，那么该小区总人数为total = key+1
        total = key + 1
        ans += math.ceil(cnts[key] / total) * total

    return ans


# 算法调用
print(getResult())
