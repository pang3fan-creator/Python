# 输入获取
a = list(map(int, input().split()))
b = list(map(int, input().split()))

maxBiggerCount = 0
ans = 0


# 算法入口
def dfs(level, used, biggerCount):
    global maxBiggerCount, ans

    if level >= len(a):
        if biggerCount > maxBiggerCount:
            maxBiggerCount = biggerCount
            ans = 1
        elif biggerCount == maxBiggerCount:
            ans += 1

        return

    for i in range(len(a)):
        if used[i]:
            continue

        used[i] = True
        # biggerCount记录当前全排列中a[level] > b[level]的位置的数量, 此时a[level] == a[i]
        dfs(level + 1, used, biggerCount + (1 if a[i] > b[level] else 0))
        used[i] = False


# 算法调用
dfs(0, [False] * len(a), 0)

print(ans)
