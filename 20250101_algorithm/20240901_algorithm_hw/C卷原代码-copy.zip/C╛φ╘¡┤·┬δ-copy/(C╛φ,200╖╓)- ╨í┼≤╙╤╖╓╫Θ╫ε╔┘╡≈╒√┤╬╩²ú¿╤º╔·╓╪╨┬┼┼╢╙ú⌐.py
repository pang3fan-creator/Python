# 分块（即连续的相同组的小朋友）
class NumberCount:
    def __init__(self, num, count):
        self.num = num
        self.count = count


# 输入获取
nums = list(map(int, input().split()))  # 初始小朋友（序号）排队顺序
sorted_nums = list(map(int, input().split()))  # 小朋友（序号）分组排队顺序

n = len(nums)

# 序号->组号 映射关系
mapping = [0] * (n + 1)
for i in range(n):
    num = sorted_nums[i]
    mapping[num] = i // 3

# 初始小朋友（组号）排队顺序
nums = map(lambda x: mapping[x], nums)


# 算法入口
def getResult():
    # 按初始排队顺序记录分块
    queue = []

    # 记录组号对应的分块， key是组号，val是对应组号的小朋友分块
    blocks = {}

    for num in nums:
        if len(queue) == 0 or queue[-1].num != num:
            # 相邻相同组号合并为块
            queue.append(NumberCount(num, 1))
            # 记录相同组号的各个分块
            blocks.setdefault(num, [])
            blocks[num].append(queue[-1])
        else:
            queue[-1].count += 1

    # 记录调整次数
    moved_count = 0
    while len(queue) > 0:
        first = queue.pop(0)

        # 如果开头块是空的，或者开头块已经包含3个小朋友，那么不需要调整位置
        if first.count == 0 or first.count == 3:
            continue

        if len(queue) == 0:
            break

        # 第二块
        second = queue[0]
        while second.count == 0:
            queue.pop(0)
            second = queue[0]

        # 如果开头块和第二块组号相同，则合并（前面并入后面）
        if first.num == second.num:
            second.count += first.count
            continue

        """
        如果开头块和第二块组号不同，则进入具体情况分析
        """

        if first.count == 2:
            # 开头块有2个小朋友，则情况如下组号1例子，此时需要将后面的单独1，并入开头两个1中，即调整一次
            # 1 1 x 1
            moved_count += 1

            # 后面单独1所在块的小朋友数量清空
            for block in blocks[first.num]:
                block.j = 0

            continue

        if first.count == 1:
            # 开头块只有1个小朋友，则有两种情况
            if len(blocks[first.num]) == 3:
                # 对于组号的分块有三个，即如下组号1例子
                # 1 x 1 y 1 z
                # 此时需要将后面两个单独1，并入到开头1中，即调整两次
                moved_count += 2
                # 后面两个单独1所在块的小朋友数量清空
                for block in blocks[first.num]:
                    block.j = 0
            else:
                # 对于组号的分块有两个，则如下组号1例子
                # 1 x 1 1
                # 此时需要将开头单独1并入到后面两个1中，即调整一次
                moved_count += 1
                # 后面两个1所在块的小朋友数量变为3个
                for block in blocks[first.num]:
                    block.j = 3

    return moved_count


# 算法调用
print(getResult())