# 输入获取
nBinStr = bin(int(input()))

mBinCharArr = list("0" + nBinStr[2:])

countOne = 0

for i in range(len(mBinCharArr) - 2, -1, -1):
    # 从右向左找到了第一组"01"子串，则替换为"10"
    if mBinCharArr[i] == '0' and mBinCharArr[i + 1] == '1':
        mBinCharArr[i] = '1'
        mBinCharArr[i + 1] = '0'

        # 如果第一组"01"子串右边存在1
        if countOne > 0:
            # 则将第一组"01"子串的右边部分的'1'要全部集中到尾部
            for j in range(i + 2, len(mBinCharArr)):
                if j < len(mBinCharArr) - countOne:
                    mBinCharArr[j] = '0'
                else:
                    mBinCharArr[j] = '1'

        break

    # 记录第一组"01"子串右边1的个数
    if mBinCharArr[i + 1] == '1':
        countOne += 1

m = int("".join(mBinCharArr), 2)

print(m)
