# 输入获取
nums = list(map(int, input().split()))
x, y = map(int, input().split())


# 算法入口
def getResult():
    rows = nums[0]
    cols = nums[1]

    graph = [-1] * (rows * cols)

    start = 0
    for i in range(2, len(nums), 2):
        gray = nums[i]
        length = nums[i + 1]

        graph[start:start + length] = [gray] * length

        start += length

    return graph[x * cols + y]


# 算法调用
print(getResult())
