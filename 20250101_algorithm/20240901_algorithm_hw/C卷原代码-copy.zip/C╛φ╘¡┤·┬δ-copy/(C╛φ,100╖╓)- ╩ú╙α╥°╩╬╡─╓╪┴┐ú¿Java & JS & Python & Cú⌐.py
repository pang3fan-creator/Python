# 输入获取
n = int(input())
weights = list(map(int, input().split()))


# 二分查找目标值位置，找不到则返回目标值在数组中有序插入位置
def binarySearch(nums, target):
    low = 0
    high = len(nums) - 1

    while low <= high:
        mid = (low + high) >> 1
        midVal = nums[mid]

        if midVal > target:
            high = mid - 1
        elif midVal < target:
            low = mid + 1
        else:
            return mid

    return -low - 1


# 算法入口
def getResult():
    weights.sort()

    while len(weights) >= 3:
        # 尾删三个最大值
        z = weights.pop()
        y = weights.pop()
        x = weights.pop()

        # 如果 x == y == z，那么下面公式结果：remain=0, 表示三块银饰完全融掉
        # 如果 x == y && y != z，那么下面公式结果：remain = z - y
        # 如果 x != y && y == z，那么下面公式结果：remain = y - x
        # 如果 x != y && y != z，那么下面公式结果：remain = Math.abs((z - y) - (y - x))
        remain = abs((z - y) - (y - x))

        # 如果还有剩余银块
        if remain != 0:
            # 那么就二分查找其在剩余升序weights中的有序插入位置
            idx = binarySearch(weights, remain)

            if idx < 0:
                idx = -idx - 1

            # 在有序插入位置插入
            weights.insert(idx, remain)

    if len(weights) == 0:
        # 如果没有剩下，就返回 0
        return 0
    else:
        # 如果剩余两块，返回较大的重量（若两块重量相同，返回任意一块皆可）
        # 如果只剩下一块，返回该块的重量
        return max(weights)


# 算法调用
print(getResult())