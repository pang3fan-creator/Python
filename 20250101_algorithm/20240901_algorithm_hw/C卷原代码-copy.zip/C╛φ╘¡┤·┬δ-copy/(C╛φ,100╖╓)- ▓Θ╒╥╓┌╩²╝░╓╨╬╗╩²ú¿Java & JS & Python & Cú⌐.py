# 输入获取
nums = list(map(int, input().split()))


# 算法入口
def getResult():
    count = {}

    # 统计各数字出现次数
    for num in nums:
        count[num] = count.get(num, 0) + 1

    # 获取最大出现次数
    maxCount = max(count.values())

    # 将众数挑选出来
    mode = []
    for k in count:
        if count[k] == maxCount:
            mode.append(int(k))

    # 众数升序
    mode.sort()

    # 中位数取值
    mid = len(mode) // 2
    if len(mode) % 2 == 0:
        # 偶数个数时，取中间两个位置的平均值
        return (mode[mid] + mode[mid - 1]) // 2
    else:
        # 奇数个数时，取中间位置的值
        return mode[mid]


# 算法调用
print(getResult())
