import re

# 输入获取
s = input()


# 压缩字符串
def zip(src):
    src += "-"

    ans = []
    stack = []
    repeat = 0

    for c in src:
        if len(stack) == 0:
            stack.append(c)
            repeat += 1
            continue

        # stack.length > 0
        top = stack[-1]
        if top == c:
            repeat += 1
            continue

        # top != c
        if repeat > 2:
            ans.append(f"{repeat}{top}")
        else:
            ans.append("".join([top] * repeat))

        stack.clear()
        stack.append(c)
        repeat = 1

    return "".join(ans)


# 算法入口
def getResult():
    # 对字符串进行备份
    back_s = s

    # 压缩字符串str只能包含小写字母和数字，如果包含其他字符则非法
    if re.search(r"[^a-z0-9]", back_s) is not None:
        return "!error"

    # 该正则用于匹配 “4a”，“12b” 这种 “数字+小写字母” 的子串
    reg = re.compile(r"(\d+)([a-z])?")

    while True:
        match = reg.search(back_s)

        if match is None:
            break

        # 要被替换的压缩子串
        src = match.group()
        repeat_times = int(match.group(1))

        # 压缩字符串中不会存在0，1，2
        if repeat_times <= 2:
            return "!error"

        repeat_content = match.group(2)

        #  abc4这种情况视为异常
        if repeat_content is None:
            return "!error"

        # 替换后的解压子串
        tar = "".join([repeat_content] * repeat_times)

        back_s = back_s.replace(src, tar, 1)

    # 如果解压字符串重新压缩后，和输入的压缩子串不一样，则说明输入的压缩字符串不合法，比如输入为3bb，bbb, 3b4b都是不合法
    if zip(back_s) != s:
        return "!error"
    else:
        return back_s


# 算法调用
print(getResult())
