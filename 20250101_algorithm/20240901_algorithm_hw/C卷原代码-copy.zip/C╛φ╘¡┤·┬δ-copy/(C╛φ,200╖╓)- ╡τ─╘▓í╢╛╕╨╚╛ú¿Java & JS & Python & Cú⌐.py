import sys

# 输入获取
n = int(input())

# 邻接表
graph = {}

m = int(input())
for i in range(m):
    # 出发点, 目标点, 出发点到达目标点的耗时
    u, v, w = map(int, input().split())
    graph.setdefault(u, [])
    graph[u].append([v, w])

# 记录源点到其他各点的最短耗时
# 初始时，假设源点不可达其他剩余点，即源点到达其他点的耗时无限大
dist = [sys.maxsize] * (n + 1)

# 源点
src = int(input())
# 源点到达源点的耗时为0
dist[src] = 0

# needCheck中记录的其实是：已被探索过的路径的终点（路径指的是源点->终点）
# 排序规则是，路径终点的权重（即源点->终点的耗时）越小越靠后
# 初始被探索过的路径只有源点本身
needCheck = [src]

# 记录对应点是否在needCheck中
visited = [False] * (n + 1)
visited[src] = True

while len(needCheck) > 0:
    # 取出最优路径的终点（耗时最少的路径）作为新的起点
    cur = needCheck.pop()
    visited[cur] = False

    # 如果cur有可达的其他点
    if graph.get(cur) is not None:
        # v是可达的其他店，w是cur->v的耗时
        for v, w in graph[cur]:
            # 那么如果从源点到cur点的耗时是dist[cur]，那么源点到v点的耗时就是dist[cur] + w
            newDist = dist[cur] + w

            # 而源点到v的耗时之前是dist[v]，因此如果newDist < dist[v]，则找到更少耗时的路径
            if dist[v] > newDist:
                # 更新源点到v的路径，即更新v点权重
                dist[v] = newDist
                # 如果v点不在needCheck中，则加入，因为v作为终点的路径需要加入到下一次最优路径的评比中
                if not visited[v]:
                    visited[v] = True
                    needCheck.append(v)
                    needCheck.sort(key=lambda x: -dist[x])

ans = max(dist[1:])

print(-1 if ans == sys.maxsize else ans)
