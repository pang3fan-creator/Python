# 输入获取
arr = list(map(int, input().split()))


# 求解去重组合
def dfs(arr, index, level, sumV, res):
    if level == 5:
        res.append(sumV)
        return

    for i in range(index, 10):
        if i > index and arr[i] == arr[i - 1]:  # arr已经升序，这里进行树层去重
            continue
        dfs(arr, i + 1, level + 1, sumV + arr[i], res)


# 算法入口
def getResult(arr):
    arr.sort()

    res = []
    # dfs求10选5的去重组合，并将组合之和记录进res中，即res中记录的是所有可能性的5人小队实力值之和
    dfs(arr, 0, 0, 0, res)

    sumV = sum(arr)
    #  某队实力为subSum，则另一队实力为sum - subSum，则两队实力差为 abs((sum - subSum) - subSum)，先求最小实力差
    return min(map(lambda subSum: abs(sumV - 2 * subSum), res))


# 算法调用
print(getResult(arr))
