import re

reg = re.compile("(([01][0-9])|([2][0-3]))[0-5][0-9]")

# 输入获取
hour, minute = input().split(":")


def dfs(arr, path, res):
    if len(path) == 4:
        timeStr = "".join(path)
        if reg.search(timeStr) is not None:
            res.append(timeStr)
        return

    for i in range(len(arr)):
        path.append(arr[i])
        dfs(arr, path, res)
        path.pop()


# 算法入口
def getResult():
    arr = list(hour)
    arr.extend(list(minute))

    arr = list(set(arr))

    res = []
    dfs(arr, [], res)
    res.sort()

    index = res.index(hour + minute)

    if index == len(res) - 1:
        recentTime = res[0]
    else:
        recentTime = res[index + 1]

    ans = list(recentTime)
    ans[1] += ":"
    return "".join(ans)


# 调用算法
print(getResult())