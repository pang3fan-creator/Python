import re

# 输入获取
s = input()


# 算法入口
def getResult():
    words = s.split()

    letter = "[aeiouAEIOU]"

    for i in range(len(words)):
        if re.search(letter, words[i]):
            words[i] = re.sub(letter, "*", words[i])
        else:
            lst = list(words[i])
            lst[0], lst[-1] = lst[-1], lst[0]
            words[i] = "".join(lst)

    return " ".join(words)


# 算法调用
print(getResult())
