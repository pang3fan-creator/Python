# 输入获取
n = int(input())
matrix = [input().split(",") for _ in range(n)]
tar = input()


def dfs(i, j, k, path):
    if i < 0 or i >= n or j < 0 or j >= n or matrix[i][j] != tar[k]:
        return False

    path.append([i, j])
    if len(path) == len(tar):
        return True

    tmp = matrix[i][j]
    matrix[i][j] = ""

    res = dfs(i - 1, j, k + 1, path) or dfs(i + 1, j, k + 1, path) or dfs(i, j - 1, k + 1, path) or dfs(i, j + 1, k + 1,
                                                                                                        path)

    if not res:
        matrix[i][j] = tmp
        path.pop()

    return res


# 算法入口
def getReuslt():
    for i in range(n):
        for j in range(n):
            path = []
            if dfs(i, j, 0, path):
                return ",".join(map(lambda x: ",".join(map(str, x)), path))

    return "N"


# 算法调用
print(getReuslt())
