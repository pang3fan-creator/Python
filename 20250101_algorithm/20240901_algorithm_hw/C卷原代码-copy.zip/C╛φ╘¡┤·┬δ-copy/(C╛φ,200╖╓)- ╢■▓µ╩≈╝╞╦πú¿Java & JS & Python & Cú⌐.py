class TreeNode:
    def __init__(self, num):
        self.num = num
        self.childSum = 0
        self.leftChild = None
        self.rightChild = None


# 输入获取
midOrder = list(map(int, input().split()))  # 中序遍历序列
preOrder = list(map(int, input().split()))  # 前序遍历序列

n = len(midOrder)

# 记录中序遍历序列中，序列元素值所在位置，本题中可能存在重复元素，因此某个序列元素值可能有多个位置
midIndexMap = {}
for j in range(n):
    num = midOrder[j]
    midIndexMap.setdefault(num, [])
    midIndexMap[num].append(j)


def notEquals(midL, preL, size):
    """
    判断两个子数组是否相同（元素相同，顺序可以不同）
    :param midL: 子数组1的左边界
    :param preL: 子数组2的左边界
    :param size: 子数组的长度
    :return: 子数组1和子数组2是否相同
    """
    arr1 = sorted(midOrder[midL:midL + size])
    arr2 = sorted(preOrder[preL:preL + size])

    for i in range(size):
        if arr1[i] != arr2[i]:
            return True

    return False


def buildTree(midL, midR, preL, preR):
    """
    根据中序遍历序列、前序遍历序列还原树结构
    :param midL: 中序遍历子序列的左边界
    :param midR: 中序遍历子序列的右边界
    :param preL: 前序遍历子序列的左边界
    :param preR: 前序遍历子序列的右边界
    :return: 树结构的根节点
    """

    # 某个节点（子树）对应一段子序列，如果对应子序列范围不存在，则子树也不存在
    if preL > preR:
        return None

    # 先根据前序遍历序列得到根节点，前序序列的首元素就是根节点
    rootNum = preOrder[preL]
    root = TreeNode(rootNum)

    # 在中序遍历序列中，找到对应根值的位置，这个位置可能有多个，但是只有一个是正确的
    for idx in midIndexMap[rootNum]:
        # 如果对应根值位置越界，则不是正确的
        if idx < midL or idx > midR:
            continue

        # 如果中序的左子树，和前序的左子树不同，则对应根值位置不正确
        leftLen = idx - midL
        if notEquals(midL, preL + 1, leftLen):
            continue

        # 如果中序的右子树，和前序的右子树不同，则对应根值位置不正确
        rightLen = midR - idx
        if notEquals(idx + 1, preR - rightLen + 1, rightLen):
            continue

        # 找到正确根值位置后，开始分治递归处理左子树和右子树
        root.leftChild = buildTree(midL, idx - 1, preL + 1, preL + leftLen)
        root.rightChild = buildTree(idx + 1, midR, preR - rightLen + 1, preR)

        leftChildSum = 0 if root.leftChild is None else (root.leftChild.num + root.leftChild.childSum)
        rightChildSUm = 0 if root.rightChild is None else (root.rightChild.num + root.rightChild.childSum)

        # 记录该节点：左子树+右子树的和（本题新二叉树节点的值）
        root.childSum = leftChildSum + rightChildSUm

        break

    return root


# 二叉树中序遍历
def getMidOrder(root, res):
    if root is None:
        return

    # 先遍历左子树
    leftChild = root.leftChild
    if leftChild is not None:
        getMidOrder(leftChild, res)

    # 再遍历根
    res.append(root.childSum)

    # 最后遍历右子树
    rightChild = root.rightChild
    if rightChild is not None:
        getMidOrder(rightChild, res)


def getResult():
    # 根据中序序列和前序序列还原树结构
    root = buildTree(0, n - 1, 0, n - 1)

    # 记录新的二叉树的的中序遍历序列
    res = []
    getMidOrder(root, res)

    return " ".join(map(str, res))


# 算法调用
print(getResult())
